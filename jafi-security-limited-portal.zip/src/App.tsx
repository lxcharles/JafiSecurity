import React, { useState, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Shield,
  Award,
  Users,
  Briefcase,
  FileText,
  Phone,
  Mail,
  MapPin,
  Search,
  Check,
  Zap,
  Clock,
  ArrowRight,
  X,
  Printer,
  ChevronRight,
  Compass,
  Lock,
  Globe,
  Map,
  Activity,
  UserCheck,
  TrendingUp,
  Server,
  ShieldAlert,
  Calendar,
  ExternalLink
} from "lucide-react";
import JafiLogo from "./components/JafiLogo";
import NationalSecurityUpdates from "./components/NationalSecurityUpdates";

// --- COMPANY CORE METRICS & SERVICE SCHEDULER ---
const SERVICES = [
  {
    id: "physical",
    title: "Physical Guard Security Services (Static & Mobile)",
    desc: "Physical Guard Security Services including Static manned and mobile mounted operational services.",
    category: "Operations",
    badge: "Static & Mobile Patrol",
    priceEstimator: 120000 // NGN / month per guard
  },
  {
    id: "cbrne",
    title: "CBRNE Equipment Procurement & Supply",
    desc: "Procurement and supply of CBRNE (Chemical, Biological, Radiological, Nuclear and Explosive) detection equipment, unexploded ordinance (UXO) and Improvised Explosive Devices (IED).",
    category: "Equipment",
    badge: "Specialist Procurement",
    priceEstimator: 4500000 
  },
  {
    id: "eod",
    title: "EOD Units Training & Certification",
    desc: "Training and retraining of Explosive Ordnance Disposal (EOD) units through our Technical Partners Teledyne/Flir Inc.",
    category: "Training",
    badge: "Technical Partnership",
    priceEstimator: 1500000
  },
  {
    id: "vip",
    title: "VIP Protection, Escort & Protocol Services",
    desc: "VIP Protection/Escort/Protocol Services catering to executive leadership, diplomatic details, and high-profile corporate escort plans.",
    category: "Operations",
    badge: "Executive Protection",
    priceEstimator: 350000
  },
  {
    id: "electronic",
    title: "Security Control Centre Officers (SCCOs)",
    desc: "Security Control Centre Officers (SCCOS) through deployment of Electronic Security Monitoring Centers (ESMC's) Visitors Management Systems (VMS) X-Ray, Baggage Scanners (XBS) and FIDO X4 Handheld Explosive Trace Detection Equipment.",
    category: "Cyber & Monitoring",
    badge: "Monitoring Services",
    priceEstimator: 600000
  },
  {
    id: "risk",
    title: "Security Risk Management & Consultation",
    desc: "Security Risk Management, Security Consultancy and Analysis to secure valuable enterprise assets and critical infrastructure.",
    category: "Consulting",
    badge: "Consultancy & Reviews",
    priceEstimator: 850000
  },
  {
    id: "biometric",
    title: "Biometric Systems & Identification",
    desc: "Biometric Systems and Identification (Biodata Analysis) configured for highly secure personnel validation and corporate monitoring.",
    category: "Consulting",
    badge: "Biodata Analytics",
    priceEstimator: 750000
  },
  {
    id: "events",
    title: "Special Events Security / BGS",
    desc: "Special Events Security Provision/BGS focusing on crowd flow management, venue safety design, and tactical logistics plans.",
    category: "Operations",
    badge: "Event Safety Operations",
    priceEstimator: 180000
  },
  {
    id: "kennel",
    title: "Kennel Services",
    desc: "Kennel Services focusing on crowd flow control, canine patrols, explosive/narcotics sniffing, and certified safety sweeps.",
    category: "Operations",
    badge: "K9 Sweeper Services",
    priceEstimator: 200000
  }
];

const getServiceIcon = (id: string) => {
  switch (id) {
    case "physical":
      return <Shield className="h-5 w-5 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-12" />;
    case "cbrne":
      return <ShieldAlert className="h-5 w-5 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-12" />;
    case "eod":
      return <Award className="h-5 w-5 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-12" />;
    case "vip":
      return <Users className="h-5 w-5 transition-transform duration-300 group-hover:scale-110 group-hover:-translate-y-1" />;
    case "electronic":
      return <Server className="h-5 w-5 transition-transform duration-300 group-hover:scale-110 group-hover:translate-y-0.5" />;
    case "risk":
      return <Lock className="h-5 w-5 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-12" />;
    case "biometric":
      return <UserCheck className="h-5 w-5 transition-transform duration-300 group-hover:scale-115" />;
    case "events":
      return <Globe className="h-5 w-5 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-90" />;
    case "kennel":
      return <Activity className="h-5 w-5 transition-transform duration-300 group-hover:scale-110 group-hover:translate-x-0.5" />;
    default:
      return <Shield className="h-5 w-5" />;
  }
};

const PORTFOLIOS = [
  {
    client: "NNPC Limited",
    location: "NNPC Towers, Abuja",
    sector: "Oil & Gas Corporation",
    personnel: "100 Security Control Center Officers (SCCOs)",
    description: "Provision of (100) Security Control Center Officers (SCCO's), Bodyshop personnel to man and operate the Electronic Security Monitoring Centers (ESMC) at NNPC Towers Abuja.",
    criticality: "High-Value Sovereign Asset"
  },
  {
    client: "NNPC Limited",
    location: "Coastal Port Stations",
    sector: "Maritime & Port Defense",
    personnel: "60 Security Control Center Officers (SCCOs)",
    facilities: [
      "Abuja Command HQ",
      "Atlas Cove Jetty",
      "Apapa Port",
      "Calabar Port",
      "Port-Harcourt Jetty",
      "Warri Jetty"
    ],
    description: "Provision of (60) (SCCO's) Bodyshop personnel to man the International Ship and Port Facility Security (ISPS) regulated control centers at Abuja Command Headquarters, Atlas Cove Jetty, Apapa Port, Calabar Port, Port-Harcourt Jetty and Warri Jetty.",
    criticality: "ISPS Port Cordon"
  },
  {
    client: "NNPC Corporate Security",
    location: "Abuja Capital",
    sector: "Corporate Security Forces",
    personnel: "Government Security Agencies (GSAs)",
    description: "Payment of stipends and pickup allowances to the Government Security Agencies (GSAs) for the NNPC Corporate Security, Abuja.",
    criticality: "Joint Agency Operations"
  },
  {
    client: "NPSC (Lot 1)",
    location: "Gombe Area Office",
    sector: "Infrastructure Safety",
    personnel: "Active Safeguard Watch Forces",
    facilities: ["Gombe Area Office & Clubhouse", "Gombe Depot & LPG", "Gombe TEG Station & Valve Pit"],
    description: "Provision of Security Guard Services for Gombe Area Office Lot1",
    criticality: "Critical Regional Infrastructure"
  },
  {
    client: "NPSC (Lot 2)",
    location: "Northeast Depots",
    sector: "Infrastructure Safety",
    personnel: "Active Safeguard Watch Forces",
    facilities: ["Maiduguri Depot", "Yola Depot", "Biu Pump Station", "Jos Depot"],
    description: "Provision of Security Guard Services for Gombe Area Office Lot2",
    criticality: "Strategic State Depots"
  },
  {
    client: "NNPC Trading Limited (NTL)",
    location: "Maitama, Abuja",
    sector: "Energy Commerce",
    personnel: "Sovereign Executive Guards",
    description: "Provision of Security Guard Services for Duke Global Energy / NNPC Trading Limited at Maitama, Abuja.",
    criticality: "Commercial Headquarters"
  },
  {
    client: "NNPC ENSERV BENIN",
    location: "Benin Station",
    sector: "Oilfield Energy Services",
    personnel: "Armed MOPOL & Civilian Guards",
    description: "Provision of armed mobile policemen and civilian guards to NNPC Energy Services formerly NNPC Oilfield Services (NOFS) Port-Harcourt.",
    criticality: "Heavy Enterprise Field Security"
  },
  {
    client: "NNPC ENSERV PORT-HARCOURT",
    location: "Port-Harcourt Station",
    sector: "Oilfield Energy Services",
    personnel: "Armed MOPOL & Civilian Guards",
    description: "Provision of armed mobile policemen and civilian guards to NNPC Energy Services formerly NNPC Oilfield Services (NOFS) Port-Harcourt.",
    criticality: "Heavy Enterprise Field Security"
  },
  {
    client: "NNPC ENSERV / FRONTIER EXPLORATION SERVICE (FES)",
    location: "Gaji-gana, Maiduguri",
    sector: "Frontier Oil Exploration",
    personnel: "Special Exploration Guards",
    facilities: ["Gaji-gana Office", "Warehouse Office Maiduguri"],
    description: "Provision of Security Guard Services for Gaji-gana and Warehouse Office Maiduguri, Borno State.",
    criticality: "Border Exploration Patrol"
  },
  {
    client: "National Open University of Nigeria (NOUN)",
    location: "NOUN Headquarters, Abuja",
    sector: "Federal Public Institutions",
    personnel: "Unified Guard Force",
    description: "Provision of Security Guard Services for National Open University of Nigeria Headquarters, Abuja",
    criticality: "Educational Infrastructure"
  },
  {
    client: "Lake Chad Research Institute (LCRI)",
    location: "Maiduguri HQ",
    sector: "Federal Public Institutions",
    personnel: "Vetted Guard Operators",
    description: "Provision of Security Guard Services for Lake Chad Research Institute, Maiduguri",
    criticality: "Strategic Academic Assets"
  },
  {
    client: "Police Trust Fund (PTF)",
    location: "PTF Headquarters, Abuja",
    sector: "Federal Agency Security",
    personnel: "Integrated Guard Detachment",
    description: "Provision of Security Guard Services at Police Trust Fund Headquarters, Abuja.",
    criticality: "Sovereign Logistics Center"
  }
];

const LEADERSHIP = [
  {
    name: "Engr. Abubakar Isa",
    role: "Managing Director / CEO",
    nationality: "Nigerian",
    credentials: "COREN Member, Principal Executive Planner",
    avatarColor: "bg-neutral-900 border-zinc-200"
  },
  {
    name: "Alh. Audu Garba",
    role: "Director",
    nationality: "Nigerian",
    credentials: "Sovereign Logistics Strategist",
    avatarColor: "bg-red-650/10 border-red-200"
  },
  {
    name: "Hajia Abubakar Hauwa",
    role: "Director",
    nationality: "Nigerian",
    credentials: "Corporate Governance & Administration Advisor",
    avatarColor: "bg-neutral-900 border-zinc-200"
  },
  {
    name: "Lamba Umar Alkali",
    role: "Director",
    nationality: "Nigerian",
    credentials: "Sovereign Audit & Executive Compliance",
    avatarColor: "bg-red-650/10 border-red-200"
  }
];

const COOPER_BIO = {
  name: "SQUADRON LEADER CHIMA I. CHIMA (RETD), FIMC, CMC",
  role: "Executive Director / COO",
  tags: ["Regular Combatant Course 35", "ADC to CAS", "NAF Bravery Award", "Fellow IMC"],
  bioSummary: "Commissioned as an Air Force Regular Combatant Officer (Course 35 Cadet) in 1986. Accumulates over 40 years of public military command and high-level corporate security management. Honored with the official Nigerian Air Force Honour for Bravery in 1991. Served successfully as Security Officer, ADC, and Chief Security Officer to the Chief of Air Staff (CAS). Fully certified as a Fellow of the Institute of Management Consultants (FIMC) and Certified Management Consultant (CMC). Served federally as Chairman of Governing Council for Federal Polytechnic Oko, and Acting Chairman for Federal Polytechnic Nekede-Owerri.",
  experienceLength: "40+ Years Military & Corporate Command"
};

const SLIDER_IMAGES = [
  "https://res.cloudinary.com/dehvk3bre/image/upload/v1781115286/file_00000000f1a07243b33af0b90d92ca6a_ogsnp7.png",
  "https://res.cloudinary.com/dehvk3bre/image/upload/v1781115288/file_00000000c89871f4af3506bfad43dc7d_hmeqga.png",
  "https://res.cloudinary.com/dehvk3bre/image/upload/v1781115282/file_0000000043207243a4d34f40448cd704_zldzsj.png"
];

export default function App() {
  const [activeTab, setActiveTab] = useState("home");
  const [sliderIndex, setSliderIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSectorFilter, setActiveSectorFilter] = useState("All");
  const [isBioModalOpen, setIsBioModalOpen] = useState(false);
  const [activeFocalService, setActiveFocalService] = useState<string>("physical");

  // --- JAFI Live Safety Desk State ---
  const [safetyBriefing, setSafetyBriefing] = useState<{
    landscape: string;
    assessment: string;
    recommendations: string[];
    sources?: { title: string; uri: string }[];
  } | null>(null);
  const [briefingLoading, setBriefingLoading] = useState<boolean>(false);
  const [briefingError, setBriefingError] = useState<string | null>(null);

  // --- Custom Operational Safety Assessment State ---
  const [assessmentDescription, setAssessmentDescription] = useState("");
  const [assessmentLoading, setAssessmentLoading] = useState(false);
  const [assessmentError, setAssessmentError] = useState<string | null>(null);
  const [assessmentResult, setAssessmentResult] = useState<{
    vulnerabilities: string[];
    recommendedServiceIds: string[];
  } | null>(null);

  // --- EOI Quotation Calculator State ---
  const [quoteForm, setQuoteForm] = useState({
    clientName: "",
    organization: "",
    email: "",
    phone: "",
    locationSecured: "Abuja Capital Sector",
    guardsNeeded: 12,
    selectedServices: ["physical"],
    threatAssessmentReq: true,
    urgencyLevel: "standard", // standard, urgent, extreme
    details: ""
  });
  const [generatedQuote, setGeneratedQuote] = useState<any>(null);

  // --- Contact Form State & Handler ---
  const [contactForm, setContactForm] = useState({
    name: "",
    organization: "",
    email: "",
    phone: "",
    subject: "Command Operations Inquiry",
    message: ""
  });
  const [isContactSubmitted, setIsContactSubmitted] = useState(false);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name.trim() || !contactForm.email.trim() || !contactForm.message.trim()) {
      return;
    }

    const emailSubject = `[COMMAND BASE INQUIRY] ${contactForm.subject} - ${contactForm.organization || contactForm.name}`;
    const emailBody = `JAFI SECURITY LIMITED - CORE DISPATCH REPORT
--------------------------------------------------
Timestamp:             ${new Date().toLocaleDateString("en-US")} (Local Abuja Time)
Status Priority:       HIGH COMMAND REVIEW

SENDER LOG:
Name:                  ${contactForm.name}
Organization:          ${contactForm.organization || "Independent Sovereign Partner"}
Contact Phone:         ${contactForm.phone || "Not Specified"}
Contact Email:         ${contactForm.email}

INQUIRY TYPE:
Subject Category:      ${contactForm.subject}

DETAILED INQUIRY MESSAGE:
--------------------------------------------------
${contactForm.message}

--------------------------------------------------
This dispatch was generated from JAFI Command Website Portal.`;

    const mailtoUrl = `mailto:contact_us@jafisecurity.com?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
    
    setIsContactSubmitted(true);
    window.location.href = mailtoUrl;

    setTimeout(() => {
      setIsContactSubmitted(false);
      setContactForm({
        name: "",
        organization: "",
        email: "",
        phone: "",
        subject: "Command Operations Inquiry",
        message: ""
      });
    }, 4500);
  };

  const handleAnalyzeSecurityRequirements = async () => {
    if (!assessmentDescription.trim()) {
      setAssessmentError("Please enter an operational description before analyzing.");
      return;
    }

    try {
      setAssessmentLoading(true);
      setAssessmentError(null);
      setAssessmentResult(null);

      const response = await fetch("/api/safety-desk/assess", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ description: assessmentDescription })
      });

      if (!response.ok) {
        throw new Error("Operational diagnostic server returned an offline indicator.");
      }

      const resData = await response.json();
      if (resData.success && resData.data) {
        setAssessmentResult(resData.data);
      } else {
        throw new Error("Failed to decode the response payload.");
      }
    } catch (err: any) {
      console.error("Assessment analysis failed:", err);
      setAssessmentError(err.message || "Failed to process. Please try again.");
    } finally {
      setAssessmentLoading(false);
    }
  };

  // Scroll to top on tab changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [activeTab]);

  // Autoplay image slider every 5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setSliderIndex((prev) => (prev + 1) % SLIDER_IMAGES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // Extract sector filters
  const sectors = useMemo(() => {
    const set = new Set(PORTFOLIOS.map(p => p.sector));
    return ["All", ...Array.from(set)];
  }, []);

  // Filter portfolio
  const filteredPortfolios = useMemo(() => {
    return PORTFOLIOS.filter(p => {
      const query = searchQuery.toLowerCase();
      const matchesQuery = 
        p.client.toLowerCase().includes(query) ||
        p.location.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query) ||
        p.sector.toLowerCase().includes(query);
      const matchesSector = activeSectorFilter === "All" || p.sector === activeSectorFilter;
      return matchesQuery && matchesSector;
    });
  }, [searchQuery, activeSectorFilter]);

  // Handle service check toggling list
  const toggleQuoteService = (serviceId: string) => {
    setQuoteForm(prev => {
      const alreadySelected = prev.selectedServices.includes(serviceId);
      if (alreadySelected) {
        if (prev.selectedServices.length === 1) return prev; // keep at least one
        return {
          ...prev,
          selectedServices: prev.selectedServices.filter(id => id !== serviceId)
        };
      } else {
        return {
          ...prev,
          selectedServices: [...prev.selectedServices, serviceId]
        };
      }
    });
  };

  // Select service and scroll to calculator
  const selectServiceAndCalculate = (serviceId: string) => {
    setQuoteForm(prev => ({
      ...prev,
      selectedServices: [serviceId]
    }));
    setActiveTab("quote");
    setTimeout(() => {
      document.getElementById("quote-wizard-card")?.scrollIntoView({ behavior: "smooth" });
    }, 120);
  };

  // Calculate quote estimate
  const handleGenerateQuote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quoteForm.clientName.trim()) {
      alert("Please provide an Authorized Officer Name.");
      return;
    }
    if (!quoteForm.email.trim()) {
      alert("Please provide Your Email Address.");
      return;
    }
    if (quoteForm.selectedServices.length === 0) {
      alert("Please select at least one Security Division service.");
      return;
    }
    
    const chosenServicesNames: string[] = [];

    quoteForm.selectedServices.forEach(id => {
      const sObj = SERVICES.find(s => s.id === id);
      if (sObj) {
        chosenServicesNames.push(sObj.title);
      }
    });

    if (quoteForm.threatAssessmentReq) {
      chosenServicesNames.push("CBRNE/Biometric Hazard Baseline Threat Assessment");
    }

    const date = new Date();
    const refNum = `JS-PORTAL-${date.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const dateString = date.toLocaleDateString("en-GB");
    const expiryString = new Date(date.getTime() + (30 * 24 * 60 * 60 * 1000)).toLocaleDateString("en-GB");

    setGeneratedQuote({
      referenceNum: refNum,
      dateString: dateString,
      expiryDate: expiryString,
      clientName: quoteForm.clientName,
      organization: quoteForm.organization || "Private Sovereign Enterprise / Ministry",
      locationSecured: quoteForm.locationSecured || "Abuja Capital Sector",
      phone: quoteForm.phone || "Not Specified",
      email: quoteForm.email,
      services: chosenServicesNames,
      guardsCount: quoteForm.guardsNeeded,
      urgency: quoteForm.urgencyLevel
    });

    // Structure EOI block for email body
    const destinationEmail = "contact_us@jafisecurity.com";
    const subject = `Official EOI Proposal Request - ${quoteForm.organization || quoteForm.clientName}`;
    const emailBody = `OFFICIAL EXPRESSION OF INTEREST (EOI) PROPOSAL REQUEST
======================================================
REFERENCE ID: ${refNum}
DATE SECURED: ${dateString}

CLIENT PROFILE
--------------
Authorized Officer Name: ${quoteForm.clientName}
Organization Name:       ${quoteForm.organization || "Private Sovereign Enterprise / Ministry"}
Contact Phone:           ${quoteForm.phone || "Not Specified"}
Contact Email:           ${quoteForm.email}

DEPLOYMENT INFORMATION
----------------------
Deployment Area Location:  ${quoteForm.locationSecured || "Abuja Capital Sector"}
Scheduled Guard Strength:  ${quoteForm.guardsNeeded} SCCO Personnel Deployed
Logistics Priority Level:  ${quoteForm.urgencyLevel.toUpperCase()}
Baseline Hazard Audit:     ${quoteForm.threatAssessmentReq ? "YES (REQUIRED)" : "NO"}

SELECTED JAFI SECURITY SERVICES
-------------------------------
${chosenServicesNames.map((name, idx) => `${idx + 1}. ${name}`).join("\n")}

This EOI proposal request has been generated officially through the JAFI Security Portal for strategic review and rapid operational mobilization.

Kind regards,
${quoteForm.clientName}`;

    const mailtoUrl = `mailto:${destinationEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(emailBody)}`;
    
    // Launch the user's native email client
    window.location.href = mailtoUrl;

    setTimeout(() => {
      document.getElementById("quotation-invoice-receipt")?.scrollIntoView({ behavior: "smooth" });
    }, 150);
  };

  const activeDivisionDetails = useMemo(() => {
    return SERVICES.find(s => s.id === activeFocalService) || SERVICES[0];
  }, [activeFocalService]);

  return (
    <div className="flex flex-col min-h-screen bg-neutral-50 text-neutral-900 selection:bg-red-600 selection:text-white font-sans antialiased">
      
      {/* 1. TOP ANNOUNCEMENT BADGE SYSTEM (Minimal Swiss Bar) */}
      <div className="bg-neutral-950 text-white text-[11px] py-2.5 px-4 sm:px-6 border-b border-neutral-800 tracking-wide font-medium">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-3">
          <div className="flex items-center space-x-3">
            <span className="inline-flex items-center font-bold tracking-wider text-red-500 uppercase text-[10px]">
              <span className="h-2 w-2 rounded-full bg-red-600 mr-2 animate-ping shrink-0"></span>
              NSCDC Licensed Category-A Security Provider
            </span>
            <span className="hidden md:inline text-neutral-800">|</span>
            <span className="hidden md:inline text-neutral-400">CAC Corporate Registration: March 15, 2007 (Nigeria)</span>
          </div>
          <div className="flex items-center space-x-4 ml-auto sm:ml-0">
            <span className="font-mono text-[10px] text-zinc-400 bg-neutral-900 px-2.5 py-0.5 rounded border border-neutral-800">
              WAT (WEST AFRICA): {new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", timeZone: "Africa/Lagos" })} (ABUJA)
            </span>
          </div>
        </div>
      </div>

      {/* 2. HEADER: Sleek designer top-navigation with Glassmorphism */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4.5 flex justify-between items-center">
          
          {/* Brand Logo Component */}
          <div className="cursor-pointer" onClick={() => setActiveTab("home")}>
            <JafiLogo />
          </div>

          {/* Floating Navigation Tabs */}
          <nav className="hidden lg:flex items-center bg-neutral-100/80 p-1 rounded-full border border-neutral-200/60">
            {[
              { id: "home", label: "Overview" },
              { id: "standing", label: "About Us" },
              { id: "services", label: "Our Services" },
              { id: "safety-desk", label: "Safety Desk" },
              { id: "experience", label: "Our Clients" },
              { id: "board", label: "Command Board" },
              { id: "quote", label: "Interactive EOI" },
              { id: "contact", label: "Contact Us" }
            ].map((tab) => (
              <button
                id={`tab-btn-${tab.id}`}
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative px-4 py-2 text-[11px] font-bold tracking-wider uppercase transition-all rounded-full ${
                  activeTab === tab.id
                    ? "bg-neutral-950 text-white shadow-md shadow-neutral-950/10"
                    : "text-neutral-600 hover:text-red-600 hover:bg-neutral-200/50"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>

          {/* Action Call key */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab("quote")}
              className="bg-red-600 hover:bg-neutral-950 active:scale-95 transition-all text-white text-[10px] font-black px-4 py-2 rounded-lg tracking-wider uppercase shadow-md shadow-red-600/15"
            >
              Get Instant Quote
            </button>
          </div>

        </div>
      </header>

      {/* 3. MOBILE TAB RAIL */}
      <div className="lg:hidden bg-white border-b border-neutral-200 overflow-x-auto whitespace-nowrap py-3 px-4 flex gap-1.5 scrollbar-none">
        {[
          { id: "home", label: "Overview" },
          { id: "standing", label: "About Us" },
          { id: "services", label: "Our Services" },
          { id: "safety-desk", label: "Safety Desk" },
          { id: "experience", label: "Our Clients" },
          { id: "board", label: "Leadership" },
          { id: "quote", label: "EOI Configurator" },
          { id: "contact", label: "Contact Us" }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-3 px-4 py-2 text-[10px] font-black tracking-widest uppercase transition-all rounded-full border shrink-0 ${
              activeTab === tab.id
                ? "bg-neutral-950 text-white border-neutral-950 shadow-md"
                : "bg-neutral-50 text-neutral-600 border-neutral-200 hover:border-red-600 hover:text-red-600"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 4. MAIN INTERACTIVE CONTENT */}
      <main className="flex-grow">

        {/* TAB 1: OVERVIEW HERO & PRESTIGE PORTFOLIO */}
        {activeTab === "home" && (
          <div className="animate-fade-in col-span-12">
            
            {/* DYNAMIC HERO SLIDER */}
            <div className="relative w-full h-[250px] sm:h-[400px] md:h-[500px] overflow-hidden bg-neutral-900 border-b border-neutral-200 group">
              <AnimatePresence mode="popLayout">
                <motion.div
                  key={sliderIndex}
                  initial={{ opacity: 0, scale: 1.02 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  transition={{ duration: 0.7, ease: "easeInOut" }}
                  className="absolute inset-0 w-full h-full"
                >
                  <img
                    src={SLIDER_IMAGES[sliderIndex]}
                    alt={`JAFI Tactical Slide ${sliderIndex + 1}`}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  {/* Subtle, dark premium gradient overlay (for high contrast readability) */}
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-black/35 to-black/15 pointer-events-none" />
                </motion.div>
              </AnimatePresence>

              {/* Slider Information Overlay */}
               <div className="absolute bottom-6 sm:bottom-10 left-4 right-4 sm:left-8 sm:right-8 md:left-12 md:right-12 z-20 flex flex-col items-start text-left text-white max-w-2xl select-none">
                <motion.span 
                  key={`tag-${sliderIndex}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1, duration: 0.4 }}
                  className="inline-flex items-center gap-1.5 bg-red-600 text-[9px] sm:text-[10px] tracking-widest font-black uppercase px-2.5 py-1 rounded shadow-md text-white"
                >
                  <span className="h-1.5 w-1.5 rounded-full bg-white animate-ping"></span>
                  {sliderIndex === 0 && "Protecting Nigeria’s Critical Assets"}
                  {sliderIndex === 1 && "Next-Generation Threat Detection"}
                  {sliderIndex === 2 && "One Innovative Security Hub"}
                </motion.span>
                <motion.h3
                  key={`title-${sliderIndex}`}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2, duration: 0.4 }}
                  className="text-sm sm:text-xl md:text-2xl lg:text-3xl font-serif font-bold tracking-tight drop-shadow-md text-white mt-2 leading-snug"
                >
                  {sliderIndex === 0 && "We engineer absolute safety for the nation’s highest-profile installations."}
                  {sliderIndex === 1 && "Fusing elite physical guarding with advanced biometric intelligence and digital surveillance."}
                  {sliderIndex === 2 && "Driven by relentless operational training to consistently exceed your expectations."}
                </motion.h3>
              </div>

              {/* Left Arrow Button */}
              <button
                onClick={() => setSliderIndex((prev) => (prev - 1 + SLIDER_IMAGES.length) % SLIDER_IMAGES.length)}
                className="absolute left-3 sm:left-5 top-1/2 -translate-y-1/2 z-25 bg-black/35 hover:bg-red-600 hover:scale-105 active:scale-95 text-white rounded-full p-2 sm:p-2.5 transition-all backdrop-blur-md border border-white/10 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 duration-300 shadow-lg cursor-pointer"
                aria-label="Previous Slide"
              >
                <ChevronRight className="h-4.5 w-4.5 rotate-180" />
              </button>

              {/* Right Arrow Button */}
              <button
                onClick={() => setSliderIndex((prev) => (prev + 1) % SLIDER_IMAGES.length)}
                className="absolute right-3 sm:right-5 top-1/2 -translate-y-1/2 z-25 bg-black/35 hover:bg-red-600 hover:scale-105 active:scale-95 text-white rounded-full p-2 sm:p-2.5 transition-all backdrop-blur-md border border-white/10 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 duration-300 shadow-lg cursor-pointer"
                aria-label="Next Slide"
              >
                <ChevronRight className="h-4.5 w-4.5" />
              </button>

              {/* Bottom Dot Indicators */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-25 flex gap-1.5 bg-black/30 px-3 py-1.5 rounded-full backdrop-blur-md border border-white/5">
                {SLIDER_IMAGES.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSliderIndex(idx)}
                    className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
                      sliderIndex === idx ? "w-5 bg-red-600" : "w-2 bg-white/40 hover:bg-white/80"
                    }`}
                    aria-label={`Go to slide ${idx + 1}`}
                  />
                ))}
              </div>
            </div>
            
            {/* HERO HERO SECTION */}
            <section className="relative overflow-hidden py-20 sm:py-28 bg-white border-b border-neutral-200">
              {/* Background atmospheric details */}
              <div className="absolute inset-0 bg-[radial-gradient(#e5e5e5_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none"></div>
              <div className="absolute top-1/4 right-0 w-96 h-96 bg-red-600/5 rounded-full blur-3xl pointer-events-none"></div>

              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-left">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
                  
                  {/* LEFT HERO TEXT - STUNNING ACCENTING & AIRY FEEL */}
                  <div className="lg:col-span-7 space-y-8">
                    
                    <div className="inline-flex items-center gap-2 bg-neutral-100 border border-neutral-200 px-3 py-1.5 rounded-full text-[10px] font-extrabold text-neutral-800 tracking-wider uppercase">
                      <span className="h-2 w-2 rounded-full bg-red-600 animate-ping"></span>
                      <span>PRESTIGE CIVILIAN DEFENSE</span>
                    </div>

                    <h1 className="text-4xl sm:text-5xl lg:text-7xl font-serif font-bold text-neutral-950 tracking-tight leading-[1.05]">
                      Advanced Tactical <br />
                      <span className="text-red-600 not-italic font-sans font-black tracking-tighter">Defense Ecosystem</span>
                    </h1>

                    <div className="space-y-4 max-w-xl">
                      <p className="text-neutral-605 text-base sm:text-lg leading-relaxed text-neutral-500">
                        Jafi Security is not just a guarding service; it is a <strong>Tier-1, Category-A defense ecosystem</strong>. Rooted in deep indigenous expertise and trusted by Nigeria's most critical infrastructure giants, Jafi seamlessly fuses elite physical boots on the ground with cutting-edge electronic warfare and tactical threat detection.
                      </p>
                      <p className="text-neutral-605 text-sm sm:text-base leading-relaxed text-neutral-500">
                        From high-profile VIP escorts to complex biometric systems and advanced CBRNE/explosive ordinance defense, they don't just react to risk—they engineer absolute safety.
                      </p>
                      <div className="pt-2 border-l-2 border-red-600 pl-4">
                        <p className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-900">
                          Jafi Security: <span className="text-red-650">Uncompromising vigilance. Mastered protection.</span>
                        </p>
                      </div>
                    </div>

                    {/* Minimal decorative matrix labels */}
                    <div className="grid grid-cols-3 gap-4 sm:gap-6 py-6 border-t border-b border-neutral-200/80 max-w-xl">
                      <div>
                        <span className="block text-[9px] uppercase tracking-widest text-neutral-400 font-bold mb-1 font-mono">STATE ACCREDITATION</span>
                        <span className="text-xs font-mono font-bold text-neutral-900 block">NSCDC CATEGORY-A</span>
                      </div>
                      <div>
                        <span className="block text-[9px] uppercase tracking-widest text-neutral-400 font-bold mb-1 font-mono">ESTABLISHED</span>
                        <span className="text-xs font-mono font-bold text-neutral-900 block">2007</span>
                      </div>
                      <div>
                        <span className="block text-[9px] uppercase tracking-widest text-neutral-400 font-bold mb-1 font-mono">EXPERIENCE</span>
                        <span className="text-xs font-mono font-bold text-neutral-900 block">{new Date().getFullYear() - 2007} YEARS</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-4 pt-2">
                      <button
                        onClick={() => setActiveTab("quote")}
                        className="bg-neutral-950 hover:bg-red-600 hover:shadow-red-600/10 transition-all text-white font-black rounded-xl px-7 py-4 text-xs uppercase tracking-wider select-none flex items-center gap-2 shadow-lg"
                      >
                        <FileText className="h-4.5 w-4.5 text-red-500 shrink-0" />
                        GET QUOTATION
                      </button>
                      <button
                        onClick={() => setActiveTab("services")}
                        className="bg-white hover:bg-neutral-100 text-neutral-950 border border-neutral-300 font-bold rounded-xl px-7 py-4 text-xs uppercase tracking-wider select-none flex items-center gap-2 transition-all"
                      >
                        EXPLORE SERVICES
                        <ArrowRight className="h-4 w-4 text-neutral-400" />
                      </button>
                    </div>
                  </div>

                  {/* RIGHT HERO HERO GRAPHIC - HIGH QUALITY COMPONENT */}
                  <div className="lg:col-span-5">
                    <div className="relative group p-4 bg-white border border-neutral-200 rounded-3xl shadow-xl shadow-neutral-200/60 max-w-md mx-auto">
                      <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-neutral-900">
                        <img
                          src="/src/assets/images/security_operations_center_1781040585684.png"
                          alt="JAFI Security Command Operations"
                          className="object-cover w-full h-full opacity-80 group-hover:scale-105 transition-transform duration-500 pointer-events-none"
                          referrerPolicy="no-referrer"
                          onError={(e: any) => {
                            e.target.style.display = 'none';
                            e.target.nextElementSibling.style.display = 'flex';
                          }}
                        />
                        
                        {/* Elegant Fallback Cover Design */}
                        <div className="hidden absolute inset-0 bg-neutral-950 p-6 flex flex-col justify-between text-left">
                          <div className="flex justify-between items-start">
                            <span className="bg-red-600/10 text-red-550 border border-red-600/20 text-[9px] font-mono font-bold px-3 py-1 rounded-md text-red-450 text-red-500">
                              COMMAND CENTER CORE
                            </span>
                            <span className="text-neutral-500 text-[9px] font-mono">JS_TAC_A9</span>
                          </div>
                          <div>
                            <p className="text-3xl font-black tracking-tighter text-white">JAFI INTEGRITY</p>
                            <p className="text-xs text-red-500 tracking-widest uppercase font-mono mt-0.5">Sovereign Guard Command System</p>
                          </div>
                          <div className="text-[9px] text-neutral-500 flex justify-between font-mono">
                            <span>PLATFORM LIVE</span>
                            <span>LAT: 9.0765° N / LON: 7.3986° E</span>
                          </div>
                        </div>

                        {/* Top Indicator */}
                        <div className="absolute top-3.5 right-3.5 bg-neutral-950/95 text-white backdrop-blur-md border border-neutral-805 py-1 px-3 rounded-lg flex items-center space-x-2">
                          <span className="h-2 w-2 rounded-full bg-red-600 animate-ping"></span>
                          <span className="font-mono text-[8px] font-bold uppercase tracking-widest text-[#fafafa]">TACTICAL HUB ONLINE</span>
                        </div>
                      </div>

                      {/* Visual metadata tag underneath */}
                      <div className="pt-4 flex justify-between items-center text-[10px] font-mono text-neutral-400 px-1">
                        <span>SYS: SEC_CENTER_CORE_01</span>
                        <span className="text-red-500 font-bold">● HQ RECEPTIVE</span>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </section>

            {/* JAFI LIVE SAFETY DESK INTRODUCTORY TEASER SECTION */}
            <section className="bg-neutral-900 text-white py-16 sm:py-20 border-t border-b border-neutral-950 relative overflow-hidden text-left">
              <div className="absolute inset-0 bg-[radial-gradient(#262626_1px,transparent_1px)] [background-size:20px_20px] opacity-35"></div>
              <div className="absolute -top-24 -right-24 h-96 w-96 bg-red-600/10 rounded-full blur-3xl"></div>
              <div className="absolute -bottom-24 -left-24 h-96 w-96 bg-red-600/5 rounded-full blur-3xl"></div>

              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
                  <div className="lg:col-span-8 space-y-4">
                    <span className="text-red-500 text-[10px] sm:text-xs font-mono font-bold uppercase tracking-widest block">
                      PROPRIETARY CORPORATE INTELLIGENCE ASSET
                    </span>
                    <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-black tracking-tight leading-tight">
                      JAFI LIVE SAFETY DESK
                    </h2>
                    <p className="text-sm sm:text-base text-neutral-400 max-w-3xl leading-relaxed">
                      JAFI Security provides real-time synthesis of current national safety data, enterprise risk assessments, and preventative protocols. This proprietary corporate intelligence asset empowers businesses to pro-actively adapt their local workflows and defend physical holdings.
                    </p>
                  </div>
                  <div className="lg:col-span-4 lg:text-right">
                    <button
                      onClick={() => setActiveTab("safety-desk")}
                      className="inline-flex items-center gap-2 bg-red-600 hover:bg-white hover:text-neutral-950 active:scale-95 transition-all text-white font-black rounded-xl px-7 py-4 text-xs uppercase tracking-wider select-none shadow-lg shadow-red-600/20 cursor-pointer"
                      id="teaser-access-intelligence-desk"
                    >
                      <Shield className="h-4.5 w-4.5 shrink-0" />
                      Access Intelligence Desk
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* DYNAMIC DIVISION SPOTLIGHT ROW */}
            <section className="bg-white py-20 text-left">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
                
                <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-6 pb-6 border-b border-neutral-200/60">
                  <div className="space-y-2">
                    <span className="text-red-600 font-mono text-xs font-bold uppercase tracking-widest block">
                      Core Operations Spotlight
                    </span>
                    <h2 className="text-3xl sm:text-4xl font-serif font-semibold text-neutral-950 tracking-tight">
                      Explore Our Key Services
                    </h2>
                  </div>
                  <div className="flex flex-wrap gap-1.5 shrink-0">
                    {SERVICES.slice(0, 4).map((s) => (
                      <button
                        key={s.id}
                        onClick={() => setActiveFocalService(s.id)}
                        className={`px-3 py-1.5 rounded-lg text-[10px] font-mono font-bold uppercase tracking-tight transition-all border ${
                          activeFocalService === s.id
                            ? "bg-red-600 text-white border-red-600 shadow-md shadow-red-600/10"
                            : "bg-white text-neutral-600 border-neutral-200 hover:border-neutral-300"
                        }`}
                      >
                        {SERVICES.find(srv => srv.id === s.id)?.badge.split(" ")[0]}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="bg-neutral-50 border border-neutral-200 rounded-3xl p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                  
                  {/* Left Column: Switcher details showcase */}
                  <div className="lg:col-span-7 space-y-6 text-left">
                    <div className="flex flex-wrap gap-2.5">
                      <span className="bg-neutral-900 text-white text-[9.5px] font-mono font-bold py-1 px-3 rounded uppercase tracking-widest border border-neutral-800">
                        {activeDivisionDetails.category}
                      </span>
                      <span className="bg-white text-red-600 border border-neutral-200 text-[10px] py-1 px-2.5 rounded font-mono font-bold uppercase tracking-tight">
                        {activeDivisionDetails.badge}
                      </span>
                    </div>

                    <h3 className="text-2xl sm:text-3xl font-serif font-black text-neutral-950 tracking-tight">
                      {activeDivisionDetails.title}
                    </h3>

                    <p className="text-sm text-neutral-500 leading-relaxed font-sans">
                      {activeDivisionDetails.desc}
                    </p>

                    <div className="bg-white p-4.5 rounded-2xl border border-neutral-200/80 flex items-center justify-between text-xs font-mono">
                      <div>
                        <span className="text-[8px] text-neutral-400 tracking-wider block font-bold uppercase">Division Dispatch Status</span>
                        <span className="font-extrabold text-emerald-600 text-xs block mt-1 uppercase tracking-tight font-sans">
                          Operational & Deployable
                        </span>
                      </div>
                      <button
                        onClick={() => selectServiceAndCalculate(activeDivisionDetails.id)}
                        className="bg-red-600 hover:bg-neutral-950 active:scale-95 text-[#fafafa] font-extrabold text-[10px] tracking-wider px-4 py-2.5 rounded-lg uppercase transition-all shadow-md shadow-red-600/15 cursor-pointer"
                      >
                        Get Quotation
                      </button>
                    </div>
                  </div>

                  {/* Right Column: Key Feature Graphics details */}
                  <div className="lg:col-span-5 bg-white border border-neutral-200 p-6 sm:p-8 rounded-2xl shadow-sm text-left space-y-4">
                    <span className="text-[10px] font-mono font-bold text-neutral-400 uppercase tracking-widest block mb-2">
                      Operational Guarantees
                    </span>
                    <ul className="space-y-3.5 text-xs text-neutral-600 font-sans">
                      <li className="flex items-start space-x-3">
                        <Check className="h-4.5 w-4.5 text-red-600 shrink-0 mt-0.5" />
                        <span className="leading-snug">
                          <strong>Rigorous State Vetting:</strong> All deployed defense personnel are strictly processed by state civil defense offices.
                        </span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="h-4.5 w-4.5 text-red-600 shrink-0 mt-0.5" />
                        <span className="leading-snug">
                          <strong>Executive Safety Standards:</strong> Premium facility security and patrol measures are formulated under elite professional oversight.
                        </span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="h-4.5 w-4.5 text-red-600 shrink-0 mt-0.5" />
                        <span className="leading-snug">
                          <strong>Direct State Status:</strong> Full Category-A licensed certification compliant with FGN sovereign law.
                        </span>
                      </li>
                    </ul>
                  </div>

                </div>

              </div>
            </section>



          </div>
        )}

        {/* TAB: JAFI LIVE SAFETY DESK STANDALONE WORKSTATION */}
        {activeTab === "safety-desk" && (
          <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16 space-y-12 animate-fade-in text-left">
            
            {/* Header presentation */}
            <div className="space-y-3 pb-6 border-b border-neutral-200">
              <span className="text-[10px] font-mono font-bold text-red-600 uppercase tracking-widest block">
                Proprietary Corporate Intelligence Platform
              </span>
              <h1 className="text-3xl sm:text-4xl font-serif font-semibold text-neutral-950 tracking-tight flex items-center gap-2">
                <Shield className="h-8 w-8 text-red-600 shrink-0" />
                JAFI Live Safety Desk
              </h1>
              <p className="text-sm text-neutral-550 max-w-3xl leading-relaxed text-neutral-500">
                Welcome to the sovereign security intelligence center. This desk synthesizes real-time national security developments, risk mitigation structures, and enterprise protection measures to secure our clients' people and physical assets across Nigeria.
              </p>
            </div>

            {/* Main Interactive Workstation Area */}
            <div className="bg-neutral-50 border border-neutral-200 rounded-3xl p-6 sm:p-10 space-y-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 h-40 w-40 bg-red-600/5 rounded-full blur-3xl pointer-events-none"></div>

              {/* Workstation Controls Block */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 border-b border-neutral-200/50 pb-6">
                <div>
                  <h3 className="text-lg font-serif font-bold text-neutral-950">
                    Live Strategic Advisories & Threat Assessment
                  </h3>
                  <p className="text-xs text-neutral-500 mt-1 uppercase font-mono tracking-wider">
                    SYS CORRELATION STATUS: SECURE CONNECTION ACTIVE
                  </p>
                </div>

                <button
                  onClick={async () => {
                    try {
                      setBriefingLoading(true);
                      setBriefingError(null);
                      setSafetyBriefing(null);
                      
                      const response = await fetch("/api/safety-desk/generate", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" }
                      });
                      
                      if (!response.ok) {
                        throw new Error("Correlation server returned an unresponsive system signal.");
                      }
                      
                      const resData = await response.json();
                      if (resData.success && resData.data) {
                        setSafetyBriefing(resData.data);
                      } else {
                        throw new Error("Unable to decode the safe intelligence response payload.");
                      }
                    } catch (err: any) {
                      console.error("Safety advisory generation failed:", err);
                      setBriefingError(err.message || "Failed to establish synchronization. Please try again.");
                    } finally {
                      setBriefingLoading(false);
                    }
                  }}
                  disabled={briefingLoading}
                  className="bg-red-600 hover:bg-neutral-950 disabled:bg-neutral-300 disabled:cursor-not-allowed text-[#fafafa] font-black text-xs uppercase tracking-wider py-4 px-6 rounded-xl transition-all shadow-md shadow-red-600/15 cursor-pointer shrink-0"
                >
                  {briefingLoading ? "Processing Intelligence..." : "Generate Real-Time Security Briefing"}
                </button>
              </div>

              {/* Workstation Core Content Area */}
              {briefingLoading && (
                <div className="py-16 flex flex-col items-center justify-center space-y-6 text-center">
                  <div className="relative flex items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-16 w-16 rounded-full bg-red-600/30"></span>
                    <span className="relative flex items-center justify-center rounded-full h-12 w-12 bg-red-600 text-white shadow-lg shadow-red-600/20">
                      <Shield className="h-6 w-6 animate-pulse" />
                    </span>
                  </div>
                  <div className="space-y-2 max-w-md">
                    <p className="text-sm font-bold text-neutral-950">
                      Synchronizing with national security feeds and analyzing current intelligence data... Please stand by.
                    </p>
                    <div className="w-48 h-1.5 bg-neutral-200 rounded-full mx-auto overflow-hidden relative">
                      <motion.div
                        className="h-full bg-red-600 rounded-full"
                        initial={{ left: "-100%" }}
                        animate={{ left: "100%" }}
                        transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                        style={{ position: "absolute", width: "50%" }}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Error Banner */}
              {!briefingLoading && briefingError && (
                <div className="bg-red-50 border border-red-200 p-6 rounded-2xl text-left space-y-3">
                  <h4 className="text-sm font-bold text-red-950">Intelligence Interface Error</h4>
                  <p className="text-xs text-red-800 leading-relaxed font-sans">
                    The intelligence server returned an unexpected threat reading or was unreachable: {briefingError}.
                  </p>
                  <p className="text-xs text-neutral-500 font-sans">
                    Please secure your network settings, verify credentials, and proceed again.
                  </p>
                </div>
              )}

              {/* Blank Welcome State */}
              {!briefingLoading && !briefingError && !safetyBriefing && (
                <div className="py-12 text-center text-neutral-400 space-y-3">
                  <Shield className="h-10 w-10 text-neutral-300 mx-auto" />
                  <p className="text-xs font-mono uppercase tracking-wider">
                    Desk Ready — Trigger Security Briefing Command Above
                  </p>
                </div>
              )}

              {/* Loaded Executives Briefing Cards */}
              {!briefingLoading && !briefingError && safetyBriefing && (
                <div className="space-y-8 animate-fade-in">
                  
                  <div className="flex items-center justify-between border-b border-neutral-200/50 pb-4">
                    <span className="text-[11px] font-mono text-neutral-405 text-neutral-400 font-bold uppercase">
                      EXECUTIVE INTELLIGENCE BRIEFING
                    </span>
                    <span className="text-[10px] font-mono text-emerald-600 font-extrabold flex items-center gap-1.5 bg-emerald-50 py-1 px-2.5 rounded-md border border-emerald-100">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                      VERIFIED & SYNCHRONIZED
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {/* Card 1: Current National Security Landscape */}
                    <div className="bg-white border border-neutral-200/80 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all space-y-4 flex flex-col justify-between">
                      <div className="space-y-3">
                        <span className="text-[10px] font-mono font-bold text-red-650 text-red-600 uppercase tracking-widest block">
                          01. landscape
                        </span>
                        <h4 className="font-serif font-bold text-base text-neutral-950">
                          Current National Security Landscape
                        </h4>
                        <p className="text-xs text-neutral-600 leading-relaxed font-sans">
                          {safetyBriefing.landscape}
                        </p>
                      </div>
                    </div>

                    {/* Card 2: JAFI Corporate Assessment */}
                    <div className="bg-white border border-neutral-200/80 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all space-y-4 flex flex-col justify-between">
                      <div className="space-y-3">
                        <span className="text-[10px] font-mono font-bold text-red-650 text-red-600 uppercase tracking-widest block">
                          02. evaluation
                        </span>
                        <h4 className="font-serif font-bold text-base text-neutral-950">
                          JAFI Corporate Assessment
                        </h4>
                        <p className="text-xs text-neutral-600 leading-relaxed font-sans">
                          {safetyBriefing.assessment}
                        </p>
                      </div>
                    </div>

                    {/* Card 3: Recommended Corporate Preventative Measures */}
                    <div className="bg-white border border-neutral-200/80 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all space-y-4 flex flex-col justify-between">
                      <div className="space-y-3">
                        <span className="text-[10px] font-mono font-bold text-red-650 text-red-600 uppercase tracking-widest block">
                          03. action protocol
                        </span>
                        <h4 className="font-serif font-bold text-base text-neutral-950">
                          Recommended Corporate Preventative Measures
                        </h4>
                        <ul className="space-y-2.5 text-xs text-neutral-600 font-sans">
                          {safetyBriefing.recommendations.map((rec, i) => (
                            <li key={i} className="flex items-start space-x-2.5">
                              <Check className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                              <span className="leading-snug">{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>

                  {/* Sources Grounding citations */}
                  {safetyBriefing.sources && safetyBriefing.sources.length > 0 && (
                    <div className="pt-6 border-t border-neutral-200/50">
                      <h5 className="text-[10px] font-mono font-bold text-neutral-400 uppercase tracking-widest mb-3 text-left">
                        Information Grounding Citations & Sources
                      </h5>
                      <div className="flex flex-wrap gap-2">
                        {safetyBriefing.sources.map((src, i) => (
                          <a
                            key={i}
                            href={src.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 bg-white border border-neutral-200 hover:border-neutral-350 hover:bg-neutral-50 px-3 py-1.5 rounded-lg text-[10px] font-mono font-bold text-neutral-700 transition cursor-pointer"
                          >
                            <span>{src.title}</span>
                            <ExternalLink className="h-3 w-3 text-neutral-400" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                </div>
              )}

            </div>

            {/* Custom Operational Safety Assessment - Automated security needs assessment tool driven by JAFI's corporate security framework */}
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-10 space-y-8 relative overflow-hidden mt-8 text-left">
              <div className="absolute top-0 right-0 h-40 w-40 bg-red-600/5 rounded-full blur-3xl pointer-events-none"></div>
              
              <div className="border-b border-neutral-200/50 pb-6">
                <span className="text-[10px] font-mono font-bold text-red-600 uppercase tracking-widest block">
                  Automated Security Needs Assessment Tool
                </span>
                <h3 className="text-xl font-serif font-semibold text-neutral-950 mt-1">
                  Custom Operational Safety Assessment
                </h3>
                <p className="text-xs text-neutral-500 mt-2 leading-relaxed">
                  Evaluate custom enterprise ventures, event vectors, and local deployment locations against JAFI's corporate security framework. Receive instant operational recommendations and transition seamlessly to a secure procurement plan.
                </p>
              </div>

              {/* User Input Module */}
              <div className="space-y-4">
                <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider">
                  Describe Corporate Operations or Upcoming Venture
                </label>
                <div className="relative">
                  <textarea
                    rows={4}
                    maxLength={1000}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl p-4 sm:p-5 text-sm font-sans focus:outline-none focus:ring-1 focus:ring-red-600 focus:bg-white transition-all text-neutral-900 leading-relaxed placeholder:text-neutral-400"
                    placeholder="Describe your upcoming venture, event, facility type, or corporate operations (e.g., 'We are hosting an international academic symposium for 5,000 attendees in Abuja' or 'Opening a new corporate logistics warehouse registry')."
                    value={assessmentDescription}
                    onChange={(e) => setAssessmentDescription(e.target.value)}
                  />
                  <div className="absolute bottom-3 right-4 text-[10px] font-mono text-neutral-400">
                    {assessmentDescription.length}/1000 characters
                  </div>
                </div>

                {assessmentError && (
                  <div className="bg-red-50 border border-red-200 text-red-805 text-xs px-4 py-3 rounded-xl flex items-center gap-2">
                    <ShieldAlert className="h-4 w-4 text-red-650 shrink-0 text-red-600" />
                    <span className="font-semibold text-red-700">{assessmentError}</span>
                  </div>
                )}

                <div className="flex justify-start pt-2">
                  <button
                    onClick={handleAnalyzeSecurityRequirements}
                    disabled={assessmentLoading}
                    className="bg-neutral-950 hover:bg-neutral-900 disabled:bg-neutral-300 disabled:cursor-not-allowed text-white font-black text-xs uppercase tracking-wider py-4 px-8 rounded-xl transition-all shadow-md active:scale-95 select-none cursor-pointer inline-flex items-center gap-2"
                  >
                    {assessmentLoading ? (
                      <>
                        <span className="h-3 w-3 border-2 border-white border-t-transparent rounded-full animate-spin shrink-0"></span>
                        Analyzing Operational Risks...
                      </>
                    ) : (
                      <>
                        <Activity className="h-4 w-4 shrink-0 text-red-500" />
                        Analyze Security Requirements
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Loader overlay representation */}
              {assessmentLoading && (
                <div className="py-12 border-t border-dashed border-neutral-200/80 flex flex-col items-center justify-center space-y-4 text-center">
                  <div className="relative flex items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-12 w-12 rounded-full bg-neutral-950/10"></span>
                    <Shield className="h-8 w-8 text-neutral-950 relative animate-pulse" />
                  </div>
                  <p className="text-xs font-mono text-neutral-700 max-w-sm">
                    Evaluating operational parameters against safety protocols... Please stand by.
                  </p>
                </div>
              )}

              {/* Assessment Outcomes Results Display */}
              {!assessmentLoading && assessmentResult && (
                <div className="space-y-8 pt-6 border-t border-dashed border-neutral-200/80 animate-fade-in text-left">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    
                    {/* Section 1: Identified Vulnerabilities & Risks */}
                    <div className="bg-neutral-50/50 border border-neutral-200/60 p-6 rounded-2xl space-y-4">
                      <div className="flex items-center gap-2 text-red-600">
                        <ShieldAlert className="h-5 w-5 shrink-0 animate-pulse" />
                        <h4 className="text-sm font-bold uppercase tracking-wider text-neutral-950 font-mono">
                          Identified Vulnerabilities & Risks
                        </h4>
                      </div>
                      <p className="text-xs text-neutral-505 text-neutral-500 leading-relaxed font-sans mb-2">
                        Synthesized danger factors matching local operational specifications:
                      </p>
                      <ul className="space-y-3.5">
                        {assessmentResult.vulnerabilities.map((vuln, index) => (
                          <li key={index} className="flex items-start gap-3 bg-white p-3.5 border border-neutral-200/50 rounded-xl hover:shadow-xs transition-shadow">
                            <span className="text-[10px] font-mono text-neutral-500 font-extrabold mt-0.5 shrink-0 w-5 h-5 flex items-center justify-center bg-neutral-100 rounded-full">
                              0{index + 1}
                            </span>
                            <span className="text-xs text-neutral-700 leading-relaxed font-sans font-medium">{vuln}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Section 2: Recommended JAFI Security Services */}
                    <div className="bg-neutral-50/50 border border-neutral-200/60 p-6 rounded-2xl space-y-4">
                      <div className="flex items-center gap-2 text-emerald-600">
                        <Check className="h-5 w-5 shrink-0 bg-emerald-50 rounded-full border border-emerald-100 p-0.5" />
                        <h4 className="text-sm font-bold uppercase tracking-wider text-neutral-950 font-mono">
                          Recommended JAFI Security Services
                        </h4>
                      </div>
                      <p className="text-xs text-neutral-505 text-neutral-500 leading-relaxed font-sans mb-2">
                        Certified enterprise countermeasures corresponding to identified weaknesses:
                      </p>
                      
                      <div className="space-y-3">
                        {SERVICES.filter(service => assessmentResult.recommendedServiceIds.includes(service.id)).map(service => (
                          <div key={service.id} className="bg-white border border-neutral-200/50 p-4 rounded-xl hover:border-neutral-300 transition-all flex justify-between items-start gap-4">
                            <div className="space-y-1">
                              <span className="text-[9px] font-mono font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded uppercase">
                                {service.badge}
                              </span>
                              <h5 className="text-xs font-bold text-neutral-950 pt-1.5 font-serif">
                                {service.title}
                              </h5>
                              <p className="text-[11px] text-neutral-505 text-neutral-500 leading-relaxed font-sans mt-0.5">
                                {service.desc}
                              </p>
                            </div>
                            <Check className="h-4 w-4 text-emerald-600 shrink-0 mt-1" />
                          </div>
                        ))}
                      </div>

                    </div>

                  </div>

                  {/* Quoting pipeline integration button block */}
                  <div className="bg-neutral-950 rounded-2xl p-6 sm:p-8 text-white relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-6 hover:shadow-lg transition-all border border-neutral-800">
                    <div className="absolute top-0 right-0 h-28 w-28 bg-emerald-500/5 rounded-full blur-xl pointer-events-none"></div>
                    <div className="space-y-1.5 text-center sm:text-left">
                      <span className="text-[9.5px] font-mono text-emerald-400 font-extrabold uppercase tracking-widest block">
                        INTEGRATED EOI CONFIGURATOR PIPELINE ACTIVE
                      </span>
                      <h4 className="text-lg font-serif font-black text-white">
                        Ready to Secure Your Operational Perimeter?
                      </h4>
                      <p className="text-xs text-neutral-400 font-sans max-w-xl">
                        Transfer these recommended parameters directly into our direct estimator. Checkbox options and details will be pre-filled automatically to accelerate high-command audit approval.
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        // Prepopulate quote checklist & details notes smoothly!
                        setQuoteForm(prev => ({
                          ...prev,
                          selectedServices: assessmentResult.recommendedServiceIds,
                          details: `[INTELLIGENCE ASSESSMENT DISPATCH DATA]
Venture Description: ${assessmentDescription}

IDENTIFIED THREAT VECTORS:
${assessmentResult.vulnerabilities.map((v, i) => `${i+1}. ${v}`).join("\n")}

AUTOMATED SYSTEM RECOMMENDATION ACTION COMPLETED.`
                        }));
                        // Route user down the lane!
                        setActiveTab("quote");
                        // Scroll to top
                        window.scrollTo({ top: 300, behavior: "smooth" });
                      }}
                      className="inline-flex items-center gap-2 bg-red-600 hover:bg-white hover:text-neutral-950 active:scale-95 transition-all text-white font-extrabold rounded-xl px-7 py-4 text-xs uppercase tracking-wider select-none shrink-0 shadow-lg shadow-red-600/15 cursor-pointer"
                    >
                      <span>GET QUOTATION</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>

                </div>
              )}

            </div>

          </div>
        )}

        {/* TAB 2: CORPORATE PROFILE & LEGAL STANDING */}
        {activeTab === "standing" && (
          <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16 space-y-12 animate-fade-in text-left">
            
            {/* Header presentation */}
            <div className="space-y-3 pb-6 border-b border-neutral-200">
              <span className="text-red-600 font-bold uppercase tracking-widest text-xs font-mono block">Strategic Foundations</span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-neutral-950 tracking-tight">
                Incorporation & Legal Mandate
              </h2>
              <p className="text-sm text-neutral-500 max-w-2xl leading-relaxed font-sans">
                JAFI SECURITY LIMITED holds pristine regulatory compliance, including the highest Category-A certification from the NSCDC, to execute physical perimeter defense, tactical VIP escorts, and advanced explosive/trace monitoring.
              </p>
            </div>

            {/* Incorporation info details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
              
              {/* CAC Certificate details */}
              <div className="bg-white border border-neutral-200 rounded-2xl p-8 flex flex-col justify-between hover:border-neutral-300 transition-all shadow-sm">
                <div className="space-y-4">
                  <div className="h-11 w-11 bg-neutral-100 border border-neutral-200 rounded-xl flex items-center justify-center">
                    <FileText className="h-5.5 w-5.5 text-neutral-900" />
                  </div>
                  <h3 className="text-xl font-bold tracking-tight text-neutral-950">Incorporated March 15, 2007</h3>
                  <p className="text-xs text-neutral-500 leading-relaxed">
                    JAFI SECURITY LIMITED was officially established under the Corporate Affairs Commission (CAC) of Nigeria. Representing persistent operational transparency and absolute corporate compliance.
                  </p>
                </div>
                <div className="pt-6 mt-6 border-t border-neutral-100 flex items-center justify-between text-[11px] font-mono text-neutral-400">
                  <span>CAC CODE: RC 685321</span>
                  <span>Established March 2007</span>
                </div>
              </div>

              {/* Private security license */}
              <div className="bg-neutral-950 text-white rounded-2xl p-8 flex flex-col justify-between hover:border-red-600 border border-neutral-850 transition-all shadow-lg relative overflow-hidden group">
                <div className="absolute top-0 right-0 h-32 w-32 bg-red-600/5 rounded-full blur-xl pointer-events-none transition-all group-hover:opacity-60"></div>
                
                <div className="space-y-4 relative z-10">
                  <div className="h-11 w-11 bg-red-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-red-600/20">
                    <Award className="h-5.5 w-5.5 text-white" />
                  </div>
                  <h3 className="text-xl font-bold tracking-tight text-[#fafafa]">Category-A Private Security License</h3>
                  <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                    Inspected, audited, and licensed directly by the Federal Government of Nigeria through the NSCDC (Nigeria Security and Civil Defence Corps). Our Category-A status confirms our eligibility to deploy multi-functional teams to secure high-profile national installations and corporate infrastructure.
                  </p>
                </div>
                
                <div className="pt-6 mt-6 border-t border-neutral-800 flex items-center justify-between text-[11px] font-mono text-neutral-400 relative z-10">
                  <span className="text-red-500 font-bold uppercase text-[10px]">NSCDC APPROVED DEPLOYER</span>
                  <span>Indigenous Private Security Services Provider</span>
                </div>
              </div>

            </div>

            {/* Core Mission Quote Box */}
            <div className="bg-white border border-neutral-200 rounded-3xl p-8 flex flex-col md:flex-row items-center gap-6 shadow-sm">
              <div className="h-16 w-16 bg-red-600 text-white rounded-full flex items-center justify-center text-3xl select-none shrink-0 italic font-serif">
                “
              </div>
              <div className="space-y-1 text-left">
                <span className="text-[9.5px] uppercase font-bold tracking-widest text-[#71717a] font-mono block">OUR PLEDGE</span>
                <p className="text-[#18181b] text-base italic leading-relaxed font-serif">
                  "We pledge to be your single, definitive security solutions hub, delivering uncompromising protection through a fusion of innovation, elite operational training, and a relentless commitment to exceeding your expectations every single day."
                </p>
              </div>
            </div>

            {/* Core Directives Grid */}
            <div className="space-y-4">
              <span className="text-xs uppercase tracking-widest text-neutral-400 font-mono font-bold block text-center">
                Operational Directives
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { num: "01", title: "Execute Comprehensive Threat and Explosive Detection", desc: "Deploy advanced CBRNE detection, baggage scanners, and trace equipment backed by continuous, technical-partner training." },
                  { num: "02", title: "Maintain Tier-1 Physical and Mobile Guarding Standards", desc: "Uphold Category-A benchmarks through elite static manned guards, mobile mounted units, and specialized VIP escort services." },
                  { num: "03", title: "Maximize Electronic Security Monitoring Center (ESMC) Capabilities", desc: "Enforce a digital perimeter using dedicated control center officers, biometric identification, and real-time surveillance." },
                  { num: "04", title: "Deliver Data-Driven Security Risk Management and Analysis", desc: "Provide continuous, tailored tactical analysis and security risk consultancy to safeguard critical national infrastructure." }
                ].map((item, idx) => (
                  <div key={idx} className="bg-white border border-neutral-200 rounded-2xl p-6 shadow-sm hover:border-red-600 transition-all font-sans">
                    <span className="block text-2xl font-mono text-red-600 font-black mb-1">{item.num}</span>
                    <h4 className="text-xs font-bold text-neutral-950 tracking-wider uppercase">{item.title}</h4>
                    <p className="text-xs text-neutral-500 leading-relaxed mt-1.5">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* TAB 3: TACTICAL SERVICE PORTFOLIO */}
        {activeTab === "services" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 space-y-12 animate-fade-in text-left">
            
            {/* Header description */}
            <div className="text-center space-y-3">
              <span className="text-red-600 font-mono font-bold uppercase tracking-widest text-xs">Tactical Services</span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-neutral-950 tracking-tight">
                Our Services & Technical Divisions
              </h2>
              <p className="text-sm text-neutral-500 max-w-xl mx-auto font-sans leading-relaxed">
                Explore our nine specialized service categories covering physical deployments, advanced biometrics, Kennel services, and certified safety procurement divisions.
              </p>
            </div>

            {/* Grid display of services */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {SERVICES.map((s) => (
                <div
                  key={s.id}
                  className="bg-white border border-neutral-200 rounded-2xl p-6 flex flex-col justify-between hover:border-red-600 hover:shadow-lg transition-all duration-300 relative overflow-hidden group"
                >
                  <div className="absolute top-0 right-0 h-24 w-24 bg-red-600/5 rounded-full blur-xl group-hover:opacity-70 transition-all"></div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="h-10 w-10 bg-neutral-50 text-neutral-800 border border-neutral-100 rounded-xl flex items-center justify-center transition-all duration-300 group-hover:bg-red-600 group-hover:text-white group-hover:border-red-600 group-hover:shadow-md group-hover:shadow-red-600/15">
                        {getServiceIcon(s.id)}
                      </div>
                      <span className="text-[10px] text-neutral-400 font-mono tracking-tight uppercase">{s.category}</span>
                    </div>

                    <div className="space-y-2">
                      <div className="inline-block">
                        <span className="bg-neutral-100 text-neutral-800 text-[10px] border border-neutral-200 font-bold uppercase py-1 px-2.5 rounded-md tracking-wider">
                          {s.badge}
                        </span>
                      </div>

                      <h3 className="text-lg font-bold text-neutral-950 group-hover:text-red-600 transition-colors">
                        {s.title}
                      </h3>

                      <p className="text-xs text-neutral-500 leading-relaxed font-sans">
                        {s.desc}
                      </p>
                    </div>
                  </div>

                  <div className="pt-6 mt-6 border-t border-neutral-100 flex items-center justify-between">
                    <button
                      onClick={() => selectServiceAndCalculate(s.id)}
                      className="text-xs text-red-600 hover:text-neutral-950 font-bold uppercase tracking-wider inline-flex items-center gap-1 transition select-none cursor-pointer"
                    >
                      Get Quotation
                      <ChevronRight className="h-3.5 w-3.5" />
                    </button>
                    <span className="text-[9px] text-neutral-400 italic">Federal standard spec</span>
                  </div>
                </div>
              ))}
            </div>

            {/* TELEDYNE PARTNERSHIP DETACHMENT */}
            <div className="bg-neutral-950 text-white rounded-3xl p-8 max-w-4xl mx-auto flex flex-col md:flex-row items-center gap-8 border border-neutral-850 shadow-xl">
              <div className="h-14 w-14 bg-red-600 text-white rounded-2xl flex items-center justify-center p-2.5 shrink-0 shadow-lg shadow-red-600/15">
                <Compass className="h-8 w-8 text-white" />
              </div>
              <div className="space-y-2 text-center md:text-left">
                <div className="flex flex-wrap gap-2.5 items-center justify-center md:justify-start">
                  <span className="bg-red-600 text-white text-[9.5px] font-mono font-bold py-0.5 px-2.5 rounded uppercase tracking-widest">
                    GLOBAL TRAINING PARTNER DETACHMENT
                  </span>
                  <span className="text-xs text-neutral-400 font-semibold uppercase">Teledyne FLIR Systems Syllabus</span>
                </div>
                <h3 className="text-xl font-bold tracking-tight text-[#fafafa]">Advanced Technology Integration Syllabus</h3>
                <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                  Our official Explosive Ordnance Disposal (EOD) training courses combine modern physical devices (such as FIDO X4 handheld explosive trace detectors) with structured base operations. This guarantees pristine compliance guarding high-value sovereign assets.
                </p>
              </div>
            </div>

          </div>
        )}

        {/* TAB 4: DEPLOYMENTS & PORTFOLIO TRACE */}
        {activeTab === "experience" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 space-y-12 animate-fade-in text-left">
            
            {/* Header */}
            <div className="text-center space-y-3">
              <span className="text-red-600 font-mono font-bold uppercase tracking-widest text-xs">Our Prestigious Clients</span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-neutral-950 tracking-tight">
                Our Clients & Services Provided
              </h2>
              <p className="text-sm text-neutral-500 max-w-xl mx-auto leading-relaxed">
                Explore our prestigious operational registry of corporate, sovereign, academic, and industrial clients where we deliver absolute protection, certified training, and logistical support.
              </p>
            </div>

            {/* Search Filter Bar */}
            <div className="bg-white border border-neutral-200 p-6 sm:p-8 rounded-3xl shadow-sm max-w-4xl mx-auto space-y-5">
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-400">
                  <Search className="h-5 w-5" />
                </span>
                <input
                  type="text"
                  className="w-full bg-neutral-50 border border-neutral-200 rounded-xl pl-11 pr-4 py-3.5 text-sm text-neutral-900 placeholder-neutral-405 focus:outline-none focus:ring-1 focus:ring-red-600 focus:bg-white transition-all font-sans"
                  placeholder="Filter by keyword (e.g., NNPC Limited, NPSC Gombe, NOUN, PTF Abuja)"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* Sector Pill Filtering */}
              <div className="flex flex-wrap justify-center gap-1.5 pt-1">
                {sectors.map((sector) => (
                  <button
                    key={sector}
                    onClick={() => setActiveSectorFilter(sector)}
                    className={`px-3.5 py-1.5 text-xs font-bold rounded-lg uppercase tracking-tight transition-all border ${
                      activeSectorFilter === sector
                        ? "bg-red-600 text-white border-red-600 shadow-md"
                        : "bg-neutral-50 hover:bg-neutral-100 text-neutral-600 border-neutral-200"
                    }`}
                  >
                    {sector === "All" ? "All Sectors" : sector}
                  </button>
                ))}
              </div>
            </div>

            {/* Total count metadata */}
            <div className="max-w-4xl mx-auto flex justify-between items-center text-xs text-neutral-450 font-mono px-2">
              <span>Showing {filteredPortfolios.length} active corporate & sovereign clients</span>
              {(searchQuery || activeSectorFilter !== "All") && (
                <button
                  onClick={() => {
                    setSearchQuery("");
                    setActiveSectorFilter("All");
                  }}
                  className="text-red-600 font-bold uppercase tracking-tight hover:underline cursor-pointer"
                >
                  Clear Filters
                </button>
              )}
            </div>

            {/* Portfolio Cards Grid */}
            <div className="max-w-4xl mx-auto space-y-6">
              {filteredPortfolios.map((p, idx) => (
                <div
                  key={idx}
                  className="bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 hover:border-red-600 hover:shadow-md transition-all divide-y divide-neutral-100"
                >
                  <div className="flex flex-col lg:flex-row lg:justify-between lg:items-start gap-4 pb-5 text-left">
                    <div className="space-y-1">
                      <span className="text-[9px] uppercase font-mono font-bold text-red-650 text-red-600 tracking-widest block">
                        SECURE CLIENT REGISTRATION
                      </span>
                      <h3 className="text-xl font-bold tracking-tight text-neutral-950 font-sans">
                        {p.client}
                      </h3>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="bg-neutral-50 text-neutral-600 text-[10px] font-mono border border-neutral-200 py-1 px-3 rounded-lg">
                        {p.location}
                      </span>
                      <span className="bg-red-50 text-red-600 text-[10px] font-mono font-bold uppercase border border-red-200 py-1 px-3 rounded-lg">
                        {p.criticality}
                      </span>
                    </div>
                  </div>

                  <div className="pt-5 grid grid-cols-1 md:grid-cols-12 gap-6 items-start text-left">
                    <div className="md:col-span-8 space-y-4">
                      <div className="space-y-1">
                        <span className="text-[9px] font-mono font-bold uppercase text-neutral-400 block">Surveillance & Guard Directives</span>
                        <p className="text-sm text-neutral-600 leading-relaxed font-sans">
                          {p.description}
                        </p>
                      </div>

                      {p.facilities && (
                        <div className="space-y-2">
                          <span className="text-[9px] font-mono font-bold uppercase text-neutral-400 block">
                            Appointed Infrastructure & Operational Points:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {p.facilities.map((fac, i) => (
                              <span
                                key={i}
                                className="bg-neutral-50 text-neutral-800 text-[10px] py-1 px-3 rounded-lg border border-neutral-200 font-sans select-none"
                              >
                                {fac}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="md:col-span-4 bg-neutral-50 border border-neutral-200 p-4.5 rounded-xl space-y-3 font-sans">
                      <div>
                        <span className="block text-[8px] uppercase tracking-wider text-[#71717a] font-mono font-bold">Tactical Guard / Deliverables Scope</span>
                        <span className="text-xs font-bold text-neutral-950 block mt-1 leading-snug">
                          {p.personnel || "Active Security Solutions"}
                        </span>
                      </div>
                      <div className="pt-3 border-t border-neutral-200 text-[10px] font-mono text-neutral-405 text-neutral-550">
                        Sector Range: {p.sector}
                      </div>
                    </div>

                  </div>
                </div>
              ))}

              {filteredPortfolios.length === 0 && (
                <div className="text-center py-16 bg-white border border-neutral-200 rounded-3xl space-y-4">
                  <div className="text-neutral-300 text-4xl">🔎</div>
                  <h4 className="text-sm font-bold text-neutral-900 uppercase">No Vetted Clients Found</h4>
                  <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                    No active assets record matches your keyword query. Reset filters to view all entries.
                  </p>
                  <button
                    onClick={() => {
                      setSearchQuery("");
                      setActiveSectorFilter("All");
                    }}
                    className="bg-red-600 text-white text-xs font-bold px-4 py-2 rounded-lg uppercase tracking-tight"
                  >
                    Reset Grid
                  </button>
                </div>
              )}
            </div>

          </div>
        )}

        {/* TAB 5: LEADERSHIP BOARD */}
        {activeTab === "board" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 space-y-16 animate-fade-in text-left">
            
            {/* Header */}
            <div className="text-center space-y-3">
              <span className="text-red-650 text-red-600 font-mono font-bold uppercase tracking-widest text-xs">Board Administration</span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-neutral-950 tracking-tight">
                Executive Leadership Board
              </h2>
              <p className="text-sm text-neutral-500 max-w-xl mx-auto leading-relaxed">
                Directed by highly experienced corporate executives and technical specialists delivering absolute compliance.
              </p>
            </div>

            {/* CHIMA CHIMA EXPANDED EXECUTIVES SPOTLIGHT CARD */}
            <div className="bg-neutral-950 text-white rounded-3xl p-6 sm:p-10 max-w-4xl mx-auto shadow-2xl relative overflow-hidden group border border-neutral-850">
              <div className="absolute top-0 right-0 h-48 w-48 bg-red-600/5 rounded-full blur-3xl pointer-events-none transition-all group-hover:bg-red-600/10"></div>
              
              <div className="flex flex-col md:flex-row gap-8 items-start relative z-10 text-left">
                
                {/* Visual badge representation instead of empty photobox */}
                <div className="h-32 w-32 bg-neutral-900 border border-neutral-800 rounded-2xl shrink-0 flex items-center justify-center p-2.5 relative self-center md:self-start group-hover:border-red-600 transition-colors shadow-inner">
                  <div className="w-full h-full border border-dashed border-neutral-700 rounded-xl flex flex-col justify-center items-center">
                    <UserCheck className="h-10 w-10 text-red-600" />
                  </div>
                </div>

                {/* Info Text */}
                <div className="space-y-4 flex-grow">
                  <div className="flex flex-wrap gap-2.5 items-center">
                    <span className="bg-red-610 bg-red-600 text-white text-[9.5px] font-mono font-bold py-0.5 px-2.5 rounded uppercase tracking-widest">
                      EXECUTIVE DIRECTOR / COO
                    </span>
                    <span className="text-xs text-neutral-400 font-mono uppercase">{COOPER_BIO.experienceLength}</span>
                  </div>

                  <h3 className="text-2xl sm:text-3xl font-serif font-black tracking-tight text-[#fafafa] leading-snug">
                    {COOPER_BIO.name}
                  </h3>

                  <p className="text-xs sm:text-[13px] text-neutral-300 font-sans leading-relaxed">
                    Commissioned into the Air Force as a Regular Cadet in 1986. Commanded critical base infrastructure and held close security protocol details with the Chief of Air Staff (CAS). Fully certified Certified Management Consultant (CMC) and Governing Council Chairman.
                  </p>

                  <div className="flex flex-wrap gap-2">
                    {COOPER_BIO.tags.map((tg, i) => (
                      <span
                        key={i}
                        className="bg-neutral-900 text-neutral-300 border border-neutral-800 text-[10px] font-mono font-semibold py-1 px-2.5 rounded-lg"
                      >
                        {tg}
                      </span>
                    ))}
                  </div>

                  <div className="pt-4">
                    <button
                      onClick={() => setIsBioModalOpen(true)}
                      className="bg-white hover:bg-red-600 hover:text-[#fafafa] hover:border-red-600 transition-all text-neutral-950 text-xs font-extrabold px-5 py-3 rounded-xl uppercase tracking-wider flex items-center gap-1.5 border border-white"
                    >
                      <UserCheck className="h-4.5 w-4.5 shrink-0" />
                      PROFILE
                    </button>
                  </div>
                </div>

              </div>
            </div>

            {/* DIRECTORS BOARD TABLE LIST */}
            <div className="max-w-4xl mx-auto space-y-5">
              <span className="text-xs uppercase tracking-widest text-[#71717a] font-mono font-bold block text-center">
                DIRECTORS
              </span>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {LEADERSHIP.map((ld, i) => (
                  <div
                    key={i}
                    className="bg-white border border-neutral-200 rounded-2xl p-6 flex flex-col justify-between hover:border-red-600 transition-all group shadow-sm text-left"
                  >
                    <div className="space-y-4">
                      <div className="flex justify-between items-start">
                        <span className="text-[10px] font-mono font-bold text-red-650 text-red-600 uppercase tracking-widest">
                          {ld.role}
                        </span>
                        <span className="text-[9px] text-neutral-400 font-mono tracking-tight uppercase">
                          {ld.nationality}
                        </span>
                      </div>
                      <h4 className="text-lg font-black text-neutral-950 group-hover:text-red-600 transition-colors">
                        {ld.name}
                      </h4>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* TAB 6: EOI CALCULATOR AND PROPOSAL GENERATOR */}
        {activeTab === "quote" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 animate-fade-in text-left">
            
            {/* Header */}
            <div className="text-center space-y-3 mb-12">
              <span className="text-red-600 font-mono font-bold uppercase tracking-widest text-xs">EOI Portal</span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-neutral-950 tracking-tight">
                Interactive EOI Configurator
              </h2>
              <p className="text-sm text-neutral-500 max-w-xl mx-auto leading-relaxed">
                Configure deployment requirements below to build your instant custom non-binding official Expression of Interest.
              </p>
                   {/* EOI Configurator Form - Centered for pristine visual layout */}
            <div className="max-w-3xl mx-auto bg-white border border-neutral-200 p-6 sm:p-8 rounded-3xl shadow-sm" id="quote-wizard-card">
              <span className="text-[10px] font-mono font-bold text-neutral-400 uppercase tracking-widest block mb-5">
                Configure Operational Requirements
              </span>

              <form onSubmit={handleGenerateQuote} className="space-y-6 font-sans">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Authorized Officer Name *</label>
                    <input
                      type="text"
                      required
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-600 focus:bg-white transition-all font-semibold"
                      placeholder="e.g., General Officer / Procurement Lead"
                      value={quoteForm.clientName}
                      onChange={(e) => setQuoteForm(prev => ({ ...prev, clientName: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Organization Name</label>
                    <input
                      type="text"
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-600 focus:bg-white transition-all"
                      placeholder="e.g., NNPC Logistics Subsidiary"
                      value={quoteForm.organization}
                      onChange={(e) => setQuoteForm(prev => ({ ...prev, organization: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Contact Number</label>
                    <input
                      type="text"
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-600 focus:bg-white transition-all"
                      placeholder="e.g., +234 803 305"
                      value={quoteForm.phone}
                      onChange={(e) => setQuoteForm(prev => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Your Email Address *</label>
                    <input
                      type="email"
                      required
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-600 focus:bg-white transition-all font-semibold"
                      placeholder="e.g., procurement@agency.gov.ng"
                      value={quoteForm.email}
                      onChange={(e) => setQuoteForm(prev => ({ ...prev, email: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Deployment Area Location</label>
                    <input
                      type="text"
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-600 focus:bg-white transition-all"
                      placeholder="e.g., Apapa Port / Gombe Depot / Abuja"
                      value={quoteForm.locationSecured}
                      onChange={(e) => setQuoteForm(prev => ({ ...prev, locationSecured: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="border-t border-neutral-100 pt-5 space-y-4">
                  <label className="block text-xs font-bold text-neutral-800 uppercase">
                    Select Required Security Divisions * (Check at least one)
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {SERVICES.map((s) => {
                      const sChecked = quoteForm.selectedServices.includes(s.id);
                      return (
                        <div
                          key={s.id}
                          onClick={() => toggleQuoteService(s.id)}
                          className={`flex items-start p-3 rounded-xl border-2 transition-all cursor-pointer ${
                            sChecked
                              ? "border-red-600 bg-red-50/25"
                              : "border-neutral-200 bg-neutral-50 hover:bg-neutral-100"
                          }`}
                        >
                          <div className="flex items-center h-5 mr-3 mt-1.5 focus:outline-none">
                            <div className={`h-4 w-4 rounded flex items-center justify-center border ${
                              sChecked ? "bg-red-600 border-red-650" : "bg-white border-neutral-300"
                            }`}>
                              {sChecked && <Check className="h-3 w-3 text-white" />}
                            </div>
                          </div>
                          <div>
                            <p className="text-xs font-bold text-neutral-900 leading-tight">
                              {s.title}
                            </p>
                            <p className="text-[10px] text-neutral-450 text-neutral-500 mt-0.5 font-semibold">
                              {s.badge}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Reactive Guard Count Slider */}
                <div className="border-t border-neutral-100 pt-5 space-y-3">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-neutral-800 uppercase">
                      Scheduled Guard Strength (Manned SCCO Force)
                    </span>
                    <span className="font-mono bg-neutral-900 text-white px-3 py-1 font-bold rounded-lg">
                      {quoteForm.guardsNeeded} Personnel Deployed
                    </span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="150"
                    className="w-full h-1.5 bg-neutral-200 rounded-lg appearance-none cursor-pointer accent-red-600"
                    value={quoteForm.guardsNeeded}
                    onChange={(e) => setQuoteForm(prev => ({ ...prev, guardsNeeded: parseInt(e.target.value) }))}
                  />
                  <div className="flex justify-between text-[10px] text-neutral-400 font-mono">
                    <span>Standard Patrol (5)</span>
                    <span>Comprehensive Facility Security (50)</span>
                    <span>Critical Infrastructure Protection (150+)</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-neutral-110 border-neutral-100 pt-5">
                  <div>
                    <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Logistics Priority Level</label>
                    <select
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none"
                      value={quoteForm.urgencyLevel}
                      onChange={(e) => setQuoteForm(prev => ({ ...prev, urgencyLevel: e.target.value }))}
                    >
                      <option value="standard">Standard Corporate Dispatch Oversight</option>
                      <option value="urgent">Corporate Urgent Priority Deployment</option>
                      <option value="extreme">Critical Priority Infrastructure Integration</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Specialist Safety & Baseline Hazard Assessment</label>
                    <div className="flex items-center space-x-3 mt-2 h-10">
                      <input
                        type="checkbox"
                        id="basethreatbox"
                        className="h-4.5 w-4.5 text-red-600 focus:ring-red-600 rounded border-neutral-300"
                        checked={quoteForm.threatAssessmentReq}
                        onChange={(e) => setQuoteForm(prev => ({ ...prev, threatAssessmentReq: e.target.checked }))}
                      />
                      <label htmlFor="basethreatbox" className="text-xs text-neutral-600 cursor-pointer">
                        Include Specialist Baseline Hazard Assessment (Recommended)
                      </label>
                    </div>
                  </div>
                </div>

                {/* Project Notes / Facility Details Area */}
                <div className="border-t border-neutral-100 pt-5 space-y-2">
                  <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider">
                    Facility Locations / Project Notes
                  </label>
                  <textarea
                    rows={5}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-600 focus:bg-white transition-all leading-relaxed text-neutral-800"
                    placeholder="Specify physical layouts, critical transit corridors, deployment constraints, or pre-filled assessment data..."
                    value={quoteForm.details}
                    onChange={(e) => setQuoteForm(prev => ({ ...prev, details: e.target.value }))}
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full bg-neutral-950 hover:bg-neutral-850 bg-red-600 hover:bg-neutral-950 text-[#fafafa] font-extrabold text-xs uppercase py-4 rounded-xl tracking-wider text-center flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <Activity className="h-4 w-4 text-[#fafafa]" />
                    Compile & Submit EOI Proposal via Email
                  </button>
                </div>

              </form>
            </div>       </div>

          </div>
        )}

        {/* TAB 7: CONTACT US PAGE */}
        {activeTab === "contact" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 animate-fade-in text-left">
            
            {/* Page Header */}
            <div className="text-center space-y-3 mb-12">
              <span className="text-red-600 font-mono font-bold uppercase tracking-widest text-xs">HEAD OFFICE</span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-neutral-950 tracking-tight">
                Secure Communications Hub
              </h2>
              <p className="text-sm text-neutral-500 max-w-xl mx-auto leading-relaxed">
                Connect directly with our headquarters, regional operational logisticians, and emergency guard dispatch coordinators.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
              
              {/* Left Column: Command base information */}
              <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
                
                {/* 1. Command HQ Card */}
                <div className="bg-white border border-neutral-200 p-6 rounded-3xl shadow-sm flex-1 flex flex-col justify-between">
                  <div>
                    <span className="text-[9px] font-mono font-bold text-red-600 uppercase tracking-widest block mb-4">
                      OUR HEAD OFFICE
                    </span>
                    <h3 className="text-sm font-black text-neutral-950 mb-3 flex items-center gap-2 uppercase tracking-wide">
                      <Shield className="h-5 w-5 text-red-600" />
                      Our Head Office
                    </h3>
                    <p className="text-xs text-neutral-500 font-sans leading-relaxed mb-6">
                      Our central headquarters and corporate administration hub, overseeing elite client deployments, advanced technical briefings, and nationwide operations.
                    </p>

                    <div className="space-y-4 font-sans text-xs">
                      <div className="flex items-start gap-3">
                        <MapPin className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-extrabold text-neutral-800 uppercase text-[10px] tracking-wider font-mono">Location Address</p>
                          <p className="text-neutral-600 mt-1 leading-relaxed">
                            Castle Rock Apartments (Building CRO2),<br />
                            P.O.W. Mafemi Crescent, Behind Chida Hotel,<br />
                            Utako, Abuja, Federal Capital Territory, Nigeria.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3 border-t border-neutral-100 pt-3">
                        <Clock className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold text-neutral-700">Days: Monday to Friday</p>
                          <p className="font-semibold text-neutral-700">Hours: Typically 9:00 AM to 5:00 PM</p>
                          <p className="text-neutral-500 text-[11px] mt-0.5">This is our operational hours</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-neutral-100 pt-5 mt-6 flex justify-between items-center text-[10px] font-mono text-neutral-400">
                    <span>STATUS: OPERATIONAL</span>
                    <span>RC 685321</span>
                  </div>
                </div>

                {/* 2. Direct Contacts Hub */}
                <div className="bg-neutral-950 text-neutral-300 p-6 rounded-3xl shadow-sm space-y-4">
                  <span className="text-[9px] font-mono font-bold text-red-400 uppercase tracking-widest block">
                    FOR INQUIRIES OR NOTICE
                  </span>
                  <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">
                    Speak with us now
                  </h4>
                  
                  <div className="space-y-3 font-mono text-xs">
                    <div className="flex items-center gap-3 py-1">
                      <Phone className="h-4 w-4 text-red-500 shrink-0" />
                      <div>
                        <p className="text-[9px] text-neutral-500 font-bold">OFFICIAL LINE 1</p>
                        <a href="tel:+2348033058864" className="text-neutral-205 hover:text-white transition-colors font-bold">+234-8033058864</a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 py-1 border-t border-neutral-800">
                      <Phone className="h-4 w-4 text-red-500 shrink-0" />
                      <div>
                        <p className="text-[9px] text-neutral-500 font-bold">OFFICIAL LINE 2</p>
                        <a href="tel:+2348142626908" className="text-neutral-205 hover:text-white transition-colors font-bold">+234-8142626908</a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 py-1 border-t border-neutral-800">
                      <Mail className="h-4 w-4 text-red-500 shrink-0" />
                      <div>
                        <p className="text-[9px] text-neutral-500 font-bold">DISPATCH EMAIL</p>
                        <a href="mailto:contact_us@jafisecurity.com" className="text-neutral-205 hover:text-red-450 transition-colors">contact_us@jafisecurity.com</a>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              {/* Right Column: Mini Command Dispatch Contact Form */}
              <div className="lg:col-span-7 bg-white border border-neutral-200 p-6 sm:p-8 rounded-3xl shadow-sm flex flex-col justify-between">
                <div>
                  <span className="text-[9px] font-mono font-bold text-neutral-400 uppercase tracking-widest block mb-5">
                    CONTACT REGISTER & DIRECT MESSAGE DISPATCH
                  </span>
                  
                  <form onSubmit={handleContactSubmit} className="space-y-5 font-sans">
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Your Name *</label>
                        <input
                          type="text"
                          required
                          className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-650 focus:bg-white transition-all font-semibold"
                          placeholder="e.g., Chief Procurement Officer"
                          value={contactForm.name}
                          onChange={(e) => setContactForm(prev => ({ ...prev, name: e.target.value }))}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Organization Name</label>
                        <input
                          type="text"
                          className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-650 focus:bg-white transition-all"
                          placeholder="e.g., maritime agency, bank, corp"
                          value={contactForm.organization}
                          onChange={(e) => setContactForm(prev => ({ ...prev, organization: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Your Email Address *</label>
                        <input
                          type="email"
                          required
                          className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-650 focus:bg-white transition-all font-semibold"
                          placeholder="e.g., rep@organization.com"
                          value={contactForm.email}
                          onChange={(e) => setContactForm(prev => ({ ...prev, email: e.target.value }))}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Contact Call Number</label>
                        <input
                          type="text"
                          className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-650 focus:bg-white transition-all font-mono"
                          placeholder="e.g., +234-803..."
                          value={contactForm.phone}
                          onChange={(e) => setContactForm(prev => ({ ...prev, phone: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Subject of Inquiry</label>
                      <select
                        className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-red-655 transition-all font-semibold"
                        value={contactForm.subject}
                        onChange={(e) => setContactForm(prev => ({ ...prev, subject: e.target.value }))}
                      >
                        <option value="Command Operations Inquiry">Command Operations & Guard Forces Dispatch</option>
                        <option value="CBRNE Detection Procurement">CBRNE & Technical Equipment Sales</option>
                        <option value="EOD Certification Training">EOD Training & Global Partnerships</option>
                        <option value="VIP Escort Protocols">VIP Escorts & Diplomatic Transportation</option>
                        <option value="Career/Guard Recruitment">Careers, Training, and Guard Recruitment</option>
                        <option value="General Agency Support">General Partnership / Corporate Inquiries</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-neutral-800 uppercase mb-2">Secure Message Details *</label>
                      <textarea
                        required
                        className="w-full bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs h-32 focus:outline-none focus:ring-1 focus:ring-red-655 focus:bg-white transition-all leading-relaxed"
                        placeholder="State your perimeter layout constraints, deployment deadlines, or administrative requirements..."
                        value={contactForm.message}
                        onChange={(e) => setContactForm(prev => ({ ...prev, message: e.target.value }))}
                      />
                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        className="w-full bg-red-600 hover:bg-neutral-950 active:scale-95 text-[#fafafa] font-extrabold text-xs uppercase py-3.5 rounded-xl tracking-wider text-center flex items-center justify-center gap-2 transition shadow-md shadow-red-600/15 cursor-pointer"
                      >
                        <Activity className="h-4 w-4 text-[#fafafa]" />
                        SEND MESSAGE
                      </button>
                    </div>

                  </form>
                </div>

                <AnimatePresence>
                  {isContactSubmitted && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="mt-4 p-3 bg-emerald-50 text-emerald-800 rounded-xl text-center text-xs font-medium border border-emerald-200"
                    >
                      ✓ Message compiled! Directing you to your email client to transmit to contact_us@jafisecurity.com
                    </motion.div>
                  )}
                </AnimatePresence>
                
              </div>

            </div>

          </div>
        )}

      </main>

      {/* 5. BIO CANVAS DRAWER MODAL */}
      <AnimatePresence>
        {isBioModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-white border border-neutral-200 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl font-sans"
            >
              
              {/* Header block */}
              <div className="bg-neutral-950 p-6 border-b border-neutral-900 flex justify-between items-center text-left text-white">
                <div>
                  <span className="text-[9.5px] uppercase font-mono font-bold text-red-500 tracking-widest block">
                    EXECUTIVE DIRECTOR PROFILE
                  </span>
                  <h3 className="text-xl font-bold mt-1 leading-none tracking-tight">
                    SQUADRON LEADER CHIMA I. CHIMA (RETD)
                  </h3>
                  <span className="text-[10px] text-neutral-400 mt-1 block font-mono font-medium">
                    COREN CERTIFIED OPERATOR & FELLOW IMC
                  </span>
                </div>
                <button
                  onClick={() => setIsBioModalOpen(false)}
                  className="text-neutral-400 hover:text-red-500 p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl"
                >
                  <X className="h-4.5 w-4.5" />
                </button>
              </div>

              {/* Bio details body */}
              <div className="p-6 space-y-5 text-left text-neutral-700 leading-relaxed text-xs sm:text-[13px]">
                
                <div className="space-y-3">
                  <h4 className="text-xs font-extrabold tracking-widest text-neutral-900 uppercase border-b border-neutral-200 pb-1">
                    1. National Commission & CAS Security Detail Command
                  </h4>
                  <p>
                    Squadron Leader Chima Mathew Chima (Retd) was commissioned as a Regular Air Force Combatant Officer under the Nigeria Air Force Regular Combatant Command Course 35 in 1986. Accumulating over 20 years of active regular service, his command capabilities earned him deep reputation across air base infrastructure and executive safety cordons.
                  </p>
                  <p>
                    Most notably, he was appointed to served as civilian and military <strong>Security Officer</strong>, <strong>Aide-de-Camp (ADC)</strong>, and <strong>Chief Security Officer (CSO)</strong> to the Chief of Air Staff (CAS). His responsiveness and logistics actions under threat profiles earned him the official <strong>Nigerian Air Force Honor for Bravery in 1991</strong>.
                  </p>
                </div>

                <div className="space-y-3">
                  <h4 className="text-xs font-extrabold tracking-widest text-[#18181b] uppercase border-b border-[#e4e4e7] pb-1">
                    2. Federal Academic Councils & Corporate Restructuring Role
                  </h4>
                  <p>
                    Following distinguished discharge from active air service, Squadron Leader Chima contributed directly to national strategic public bodies. He was appointed by the Federal Republic as <strong>Chairman of the Governing Council for Federal Polytechnic, Oko (Anambra State)</strong>, and subsequently served as <strong>Acting Chairman of the Governing Council for Federal Polytechnic, Nekede-Owerri</strong>.
                  </p>
                  <p>
                    Operating professionally in the corporate sector, he maintains high-tier standing as a <strong>Fellow of the Institute of Management Consultants (FIMC)</strong> and is fully certified as an international <strong>Certified Management Consultant (CMC)</strong>. In his central role as Executive Director of Operations and Chief Operating Officer of JAFI Security Limited, he establishes and directs defensive force deployments guarding pipeline ports, logistics centers, open university hubs, and private brokerage agencies.
                  </p>
                </div>

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* AUTOMATED SECURITY NEEDS ASSESSMENT TOOL - HOMEPAGE INTEGRATION */}
      {activeTab === "home" && (
        <section className="bg-neutral-100 py-16 sm:py-20 border-t border-b border-neutral-200 text-left">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 animate-fade-in">
            
            <div className="text-center space-y-3">
              <span className="text-red-600 text-xs font-mono font-bold uppercase tracking-widest block">
                Enterprise Diagnostic Tool
              </span>
              <h2 className="text-3xl sm:text-4xl font-serif font-semibold text-neutral-950 tracking-tight">
                Automated Security Needs Assessment
              </h2>
              <p className="text-sm text-neutral-500 max-w-2xl mx-auto leading-relaxed text-center">
                Evaluate custom enterprise ventures, event vectors, and local deployment locations against JAFI's corporate security framework. Receive instant operational recommendations and transition seamlessly to a secure procurement plan.
              </p>
            </div>

            <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-10 space-y-8 relative overflow-hidden shadow-sm">
              <div className="absolute top-0 right-0 h-40 w-40 bg-red-600/5 rounded-full blur-3xl pointer-events-none"></div>

              {/* User Input Module */}
              <div className="space-y-4">
                <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider">
                  Describe Corporate Operations, Event Type, or Facility Locations
                </label>
                <div className="relative">
                  <textarea
                    rows={4}
                    maxLength={1000}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl p-4 sm:p-5 text-sm font-sans focus:outline-none focus:ring-1 focus:ring-red-600 focus:bg-white transition-all text-neutral-900 leading-relaxed placeholder:text-neutral-400"
                    placeholder="Describe your upcoming venture, event, facility type, or corporate operations (e.g., 'Opening a new corporate logistics warehouse registry' or 'We are hosting an international academic symposium for 5,000 attendees in Abuja')."
                    value={assessmentDescription}
                    onChange={(e) => setAssessmentDescription(e.target.value)}
                  />
                  <div className="absolute bottom-3 right-4 text-[10px] font-mono text-neutral-400">
                    {assessmentDescription.length}/1000 characters
                  </div>
                </div>

                {assessmentError && (
                  <div className="bg-red-50 border border-red-200 text-red-800 text-xs px-4 py-3 rounded-xl flex items-center gap-2">
                    <ShieldAlert className="h-4 w-4 text-red-650 shrink-0 text-red-600" />
                    <span className="font-semibold text-red-700">{assessmentError}</span>
                  </div>
                )}

                <div className="flex justify-start pt-2">
                  <button
                    onClick={handleAnalyzeSecurityRequirements}
                    disabled={assessmentLoading}
                    className="bg-neutral-950 hover:bg-neutral-900 disabled:bg-neutral-300 disabled:cursor-not-allowed text-white font-black text-xs uppercase tracking-wider py-4 px-8 rounded-xl transition-all shadow-md active:scale-95 select-none cursor-pointer inline-flex items-center gap-2"
                  >
                    {assessmentLoading ? (
                      <>
                        <span className="h-3 w-3 border-2 border-white border-t-transparent rounded-full animate-spin shrink-0"></span>
                        Analyzing Operational Risks...
                      </>
                    ) : (
                      <>
                        <Activity className="h-4 w-4 shrink-0 text-red-500" />
                        Analyze Requirements
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Loader overlay representation */}
              {assessmentLoading && (
                <div className="py-12 border-t border-dashed border-neutral-200/80 flex flex-col items-center justify-center space-y-4 text-center">
                  <div className="relative flex items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-12 w-12 rounded-full bg-neutral-950/10"></span>
                    <Shield className="h-8 w-8 text-neutral-950 relative animate-pulse" />
                  </div>
                  <p className="text-xs font-mono text-neutral-700 max-w-sm">
                    Evaluating operational parameters against safety protocols... Please stand by.
                  </p>
                </div>
              )}

              {/* Assessment Outcomes Results Display */}
              {!assessmentLoading && assessmentResult && (
                <div className="space-y-8 pt-6 border-t border-dashed border-neutral-200/80 animate-fade-in text-left">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    
                    {/* Section 1: Identified Vulnerabilities & Risks */}
                    <div className="bg-neutral-50/50 border border-neutral-200/60 p-6 rounded-2xl space-y-4">
                      <div className="flex items-center gap-2 text-red-600">
                        <ShieldAlert className="h-5 w-5 shrink-0 animate-pulse" />
                        <h4 className="text-sm font-bold uppercase tracking-wider text-neutral-950 font-mono">
                          Identified Vulnerabilities & Risks
                        </h4>
                      </div>
                      <p className="text-xs text-neutral-505 text-neutral-500 leading-relaxed font-sans mb-2">
                        Synthesized danger factors matching local operational specifications:
                      </p>
                      <ul className="space-y-3.5">
                        {assessmentResult.vulnerabilities.map((vuln, index) => (
                          <li key={index} className="flex items-start gap-3 bg-white p-3.5 border border-neutral-200/50 rounded-xl hover:shadow-xs transition-shadow">
                            <span className="text-[10px] font-mono text-neutral-500 font-extrabold mt-0.5 shrink-0 w-5 h-5 flex items-center justify-center bg-neutral-100 rounded-full">
                              0{index + 1}
                            </span>
                            <span className="text-xs text-neutral-700 leading-relaxed font-sans font-medium">{vuln}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Section 2: Recommended JAFI Security Services */}
                    <div className="bg-neutral-50/50 border border-neutral-200/60 p-6 rounded-2xl space-y-4">
                      <div className="flex items-center gap-2 text-emerald-600">
                        <Check className="h-5 w-5 shrink-0 bg-emerald-50 rounded-full border border-emerald-100 p-0.5" />
                        <h4 className="text-sm font-bold uppercase tracking-wider text-neutral-950 font-mono">
                          Recommended JAFI Security Services
                        </h4>
                      </div>
                      <p className="text-xs text-neutral-550 text-neutral-500 leading-relaxed font-sans mb-2">
                        Certified enterprise countermeasures corresponding to identified weaknesses:
                      </p>
                      
                      <div className="space-y-3">
                        {SERVICES.filter(service => assessmentResult.recommendedServiceIds.includes(service.id)).map(service => (
                          <div key={service.id} className="bg-white border border-neutral-200/50 p-4 rounded-xl hover:border-neutral-300 transition-all flex justify-between items-start gap-4">
                            <div className="space-y-1">
                              <span className="text-[9px] font-mono font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded uppercase">
                                {service.badge}
                              </span>
                              <h5 className="text-xs font-bold text-neutral-950 pt-1.5 font-serif">
                                {service.title}
                              </h5>
                              <p className="text-[11px] text-neutral-550 text-neutral-500 leading-relaxed font-sans mt-0.5">
                                {service.desc}
                              </p>
                            </div>
                            <Check className="h-4 w-4 text-emerald-600 shrink-0 mt-1" />
                          </div>
                        ))}
                      </div>

                    </div>

                  </div>

                  {/* Quoting pipeline integration button block */}
                  <div className="bg-neutral-950 rounded-2xl p-6 sm:p-8 text-white relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-6 hover:shadow-lg transition-all border border-neutral-800">
                    <div className="absolute top-0 right-0 h-28 w-28 bg-emerald-500/5 rounded-full blur-xl pointer-events-none"></div>
                    <div className="space-y-1.5 text-center sm:text-left">
                      <span className="text-[9.5px] font-mono text-emerald-400 font-extrabold uppercase tracking-widest block">
                        INTEGRATED EOI CONFIGURATOR PIPELINE ACTIVE
                      </span>
                      <h4 className="text-lg font-serif font-black text-white">
                        Ready to Secure Your Operational Perimeter?
                      </h4>
                      <p className="text-xs text-neutral-400 font-sans max-w-xl">
                        Transfer these recommended parameters directly into our direct estimator. Checkbox options and details will be pre-filled automatically to accelerate high-command audit approval.
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        // Prepopulate quote checklist & details notes smoothly!
                        setQuoteForm(prev => ({
                          ...prev,
                          selectedServices: assessmentResult.recommendedServiceIds,
                          details: assessmentDescription
                        }));
                        // Route user down the lane!
                        setActiveTab("quote");
                        // Scroll to top
                        window.scrollTo({ top: 300, behavior: "smooth" });
                      }}
                      className="inline-flex items-center gap-2 bg-red-600 hover:bg-white hover:text-neutral-950 active:scale-95 transition-all text-white font-extrabold rounded-xl px-7 py-4 text-xs uppercase tracking-wider select-none shrink-0 shadow-lg shadow-red-600/15 cursor-pointer"
                    >
                      <span>GET QUOTATION</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>

                </div>
              )}

            </div>

          </div>
        </section>
      )}

      {/* OUR PROMINENT CLIENTS & PARTNERS LOGO TICKER */}
      <section className="bg-neutral-50/70 border-t border-neutral-100 py-12 overflow-hidden select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8 text-center sm:text-center">
          <span className="text-[10px] font-mono font-bold text-red-600 uppercase tracking-widest block mb-1">
            TRUSTED PARTNERSHIPS
          </span>
          <h3 className="text-[12px] font-mono tracking-widest uppercase font-black text-neutral-800">
            Our Prominent Clients & Partners
          </h3>
          <p className="text-[11px] text-neutral-500 font-sans mt-1">
            Securing national learning environments, corporate headquarters, and vital state assets.
          </p>
        </div>

        {/* Marquee viewport */}
        <div className="relative w-full overflow-hidden flex items-center py-2 bg-white border-t border-b border-neutral-200/50">
          {/* Ambient Fade overlay on both sides for premium feel */}
          <div className="absolute left-0 top-0 bottom-0 w-20 md:w-40 bg-gradient-to-r from-neutral-50 to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-20 md:w-40 bg-gradient-to-l from-neutral-50 to-transparent z-10 pointer-events-none" />

          {/* Scrolling wrapper containing 2 copies for perfect seamless loop */}
          <div className="flex w-max gap-16 py-3 animate-marquee shrink-0 items-center">
            {/* First Set of Logos */}
            {[
              "https://res.cloudinary.com/dehvk3bre/image/upload/v1781119465/Noun_logo_15188682875-650x657-1_p6bmbv.jpg",
              "https://res.cloudinary.com/dehvk3bre/image/upload/v1781119465/logo-dark_itspsn.png",
              "https://res.cloudinary.com/dehvk3bre/image/upload/v1781119466/images_5_rn5bbu.png",
              "https://res.cloudinary.com/dehvk3bre/image/upload/v1781119465/cropped-new-logo_j3rfy7.png",
              "https://res.cloudinary.com/dehvk3bre/image/upload/v1781119466/Nigerian_National_Petroleum_Company_logo.svg_bi98rf.png"
            ].map((logo, idx) => (
              <img
                key={`logo-primary-${idx}`}
                src={logo}
                alt="JAFI Security Client Logo"
                className="h-10 sm:h-12 w-auto mx-8 object-contain opacity-90 hover:opacity-100 transition-all duration-300 transform hover:scale-105"
                referrerPolicy="no-referrer"
              />
            ))}
            {/* Second Set of Logos (Identical duplicate for seamless continuous animation) */}
            {[
              "https://res.cloudinary.com/dehvk3bre/image/upload/v1781119465/Noun_logo_15188682875-650x657-1_p6bmbv.jpg",
              "https://res.cloudinary.com/dehvk3bre/image/upload/v1781119465/logo-dark_itspsn.png",
              "https://res.cloudinary.com/dehvk3bre/image/upload/v1781119466/images_5_rn5bbu.png",
              "https://res.cloudinary.com/dehvk3bre/image/upload/v1781119465/cropped-new-logo_j3rfy7.png",
              "https://res.cloudinary.com/dehvk3bre/image/upload/v1781119466/Nigerian_National_Petroleum_Company_logo.svg_bi98rf.png"
            ].map((logo, idx) => (
              <img
                key={`logo-secondary-${idx}`}
                src={logo}
                alt="JAFI Security Client Logo Repeat"
                className="h-10 sm:h-12 w-auto mx-8 object-contain opacity-90 hover:opacity-100 transition-all duration-300 transform hover:scale-105"
                referrerPolicy="no-referrer"
              />
            ))}
          </div>
        </div>
      </section>

      {/* 6. GORGEOUS SUSTAINED FOOTER */}
      <footer className="bg-neutral-950 text-neutral-400 border-t border-neutral-800 pt-16 pb-8 text-xs font-sans">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-neutral-900 text-left">
          
          {/* Logo & compliance */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <img
                src="https://res.cloudinary.com/dehvk3bre/image/upload/v1781112383/20260610_182551_aqscap.png"
                alt="JAFI Security Logo"
                className="h-8 md:h-10 w-auto object-contain"
                referrerPolicy="no-referrer"
              />
              <span className="text-lg font-black tracking-tight text-white uppercase">
                JAFI <span className="text-red-550 font-light text-red-500">SECURITY</span>
              </span>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed max-w-sm">
              JAFI SECURITY LIMITED protects multi-billion Naira strategic pipeline junctions, coastal maritime port depots, public universities, and executive asset perimeters across Nigeria.
            </p>
            <div className="text-[10px] text-neutral-500 space-y-0.5 font-mono block">
              <p>Corporate affairs: CAC RC-685321 (Incorporated March 2007)</p>
              <p>State Status: Certified Category-A Manned Guard Provider</p>
            </div>
          </div>

          {/* Srv range checklist */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="text-[10px] font-mono uppercase font-bold text-white tracking-widest border-b border-neutral-800 pb-2">
              OUR SERVICES
            </h4>
            <ul className="space-y-2 text-[11px] text-neutral-400 font-sans">
              {[
                "Static Manned Security Guards",
                "CBRNE Toxic Material Isolation",
                "Advanced EOD Partner Modules",
                "VIP Armored Transportation Protocols",
                "Electronic Asset Visitor Gate SCCOs",
                "K9 Explosives Sniffer Sweeps"
              ].map((item, idx) => (
                <li key={idx} className="flex items-center space-x-2">
                  <span className="h-1 w-1 rounded-full bg-red-600"></span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-[10px] font-mono uppercase font-bold text-white tracking-widest border-b border-neutral-800 pb-2">
              OUR HEAD OFFICE
            </h4>
            <div className="space-y-3 leading-relaxed text-[11px]">
              <div className="flex items-start space-x-2 text-neutral-400">
                <MapPin className="h-4 w-4 text-red-605 text-red-600 shrink-0 mt-0.5" />
                <p>
                  Castle Rock Apartments (Building CRO2),<br />
                  P.O.W. Mafemi Crescent, Behind Chida Hotel,<br />
                  Utako, Abuja, Federal Capital Territory, Nigeria.
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-3.5 w-3.5 text-red-600 shrink-0" />
                <span className="font-mono text-neutral-300">+234-8033058864, +234-8142626908</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-3.5 w-3.5 text-red-600 shrink-0" />
                <a href="mailto:contact_us@jafisecurity.com" className="font-mono hover:text-red-500 transition-colors">
                  contact_us@jafisecurity.com
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* copyright subfooter */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] text-neutral-500 text-center sm:text-left">
          <p>© {new Date().getFullYear()} JAFI SECURITY LIMITED. All defensive protocols, CAC registration, and sovereign regulatory standards comply with FGN law.</p>
          <div className="flex space-x-2 shrink-0">
            <span className="bg-neutral-900 text-neutral-400 px-3 py-1 rounded inline-block border border-neutral-800 tracking-wider text-[9px] uppercase font-bold">
              Sovereign Shield Category A
            </span>
          </div>
        </div>

      </footer>

    </div>
  );
}
