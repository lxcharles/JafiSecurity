import React from "react";

interface JafiLogoProps {
  className?: string;
  iconOnly?: boolean;
}

export default function JafiLogo({ className = "", iconOnly = false }: JafiLogoProps) {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Brandmark - Official High-Quality Image Asset */}
      <img
        src="https://res.cloudinary.com/dehvk3bre/image/upload/v1781110908/20260610_174927_hi9au5.png"
        alt="JAFI Security Logo"
        className="h-9 md:h-11 w-auto object-contain drop-shadow-sm hover:scale-105 transition-transform duration-300"
        referrerPolicy="no-referrer"
      />

      {!iconOnly && (
        <div className="flex flex-col text-left">
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-black tracking-tight text-neutral-950 dark:text-neutral-950 uppercase">
              JAFI
            </span>
            <span className="text-xs font-semibold uppercase tracking-wider text-red-650 text-red-600">
              Security
            </span>
          </div>
          <span className="font-mono text-[8px] text-zinc-550 leading-none uppercase tracking-widest mt-0.5">
            RC NO. 685321 | Category-A
          </span>
        </div>
      )}
    </div>
  );
}
